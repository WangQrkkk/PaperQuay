﻿import clsx from 'clsx';
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
} from 'react';
import { getCurrentWindow } from '@tauri-apps/api/window';
import {
  BookOpenText,
  Database,
  FolderOpen,
  Languages,
  Library,
  Minus,
  PanelLeftClose,
  PanelLeftOpen,
  Settings2,
  Sparkles,
  Square,
  X,
} from 'lucide-react';
import TabBar from '../../components/tabs/TabBar';
import LibraryPreviewPane from '../library/LibraryPreviewPane';
import LibraryWorkspace from '../library/LibraryWorkspace';
import DocumentReaderTab, {
  type LibraryPreviewSyncPayload,
  type ReaderTabBridgeState,
} from './DocumentReaderTab';
import {
  getAppDefaultPaths,
  readLocalBinaryFile,
  readLocalTextFile,
  runMineruCloudParse,
  selectDirectory,
  selectLocalPdfSource,
  writeLocalTextFile,
} from '../../services/desktop';
import type { AppDefaultPaths } from '../../services/desktop';
import {
  flattenMineruPages,
  parseMineruPages,
} from '../../services/mineru';
import { testOpenAICompatibleChat } from '../../services/llm';
import { summarizeDocumentOpenAICompatible } from '../../services/summary';
import {
  buildMineruMarkdownDocument,
  buildSummaryBlockInputs,
  extractPdfTextByPdfJs,
  SUMMARY_PROMPT_VERSION,
} from '../../services/summarySource';
import {
  detectLocalZoteroDataDir,
  listLocalZoteroCollectionItems,
  listLocalZoteroCollections,
  listLocalZoteroLibraryItems,
  selectLocalZoteroDataDir,
} from '../../services/zotero';
import {
  getHomeTabTitle,
  HOME_TAB_ID,
  useTabsStore,
  type ReaderTab,
} from '../../stores/useTabsStore';
import type {
  FlatCollection,
  LibrarySectionKey,
  OpenAICompatibleTestResult,
  PaperSummary,
  QaModelPreset,
  ReaderConfigFile,
  ReaderSecrets,
  ReaderSettings,
  SummarySourceMode,
  TranslationDisplayMode,
  UiLanguage,
  PositionedMineruBlock,
  WorkspaceItem,
  ZoteroCollection,
  ZoteroLibraryItem,
} from '../../types/reader';
import { AppLocaleProvider, useAppLocale } from '../../i18n/uiLanguage';
import { truncateMiddle, getFileNameFromPath } from '../../utils/text';
import {
  buildLegacyMineruCachePaths,
  buildLegacyMineruSummaryCachePath,
  buildMineruCachePaths,
  buildMineruSummaryCachePath,
  guessSiblingJsonPath,
  guessSiblingMarkdownPath,
} from '../../utils/mineruCache';
import { loadPaperHistory } from '../../utils/paperHistory';

const SETTINGS_STORAGE_KEY = 'paper-reader-settings-v3';
const SECRETS_STORAGE_KEY = 'paper-reader-secrets-v1';
const LEFT_SIDEBAR_COLLAPSED_STORAGE_KEY = 'paper-reader-left-sidebar-collapsed-v1';
const DEFAULT_QA_PRESET_ID = 'default';
const READER_CONFIG_VERSION = 1;

function pickLocaleText<T>(locale: UiLanguage, zh: T, en: T): T {
  return locale === 'en-US' ? en : zh;
}

function buildLanguageOptions(locale: UiLanguage) {
  return [
    { value: 'auto', label: pickLocaleText(locale, '自动识别', 'Auto Detect') },
    { value: 'English', label: 'English' },
    { value: 'Chinese', label: pickLocaleText(locale, '中文', 'Chinese') },
    { value: 'Japanese', label: pickLocaleText(locale, '日语', 'Japanese') },
    { value: 'Korean', label: pickLocaleText(locale, '韩语', 'Korean') },
    { value: 'French', label: pickLocaleText(locale, '法语', 'French') },
    { value: 'German', label: 'Deutsch' },
    { value: 'Spanish', label: pickLocaleText(locale, '西班牙语', 'Spanish') },
  ];
}

function buildSummarySourceOptions(locale: UiLanguage): Array<{
  value: SummarySourceMode;
  label: string;
  description: string;
}> {
  return [
    {
      value: 'mineru-markdown',
      label: 'MinerU Markdown',
      description: pickLocaleText(
        locale,
        '优先读取 full.md 作为主要输入，若不存在则回退到块级文本。',
        'Prefer reading full.md as the primary input, and fall back to block text if it is unavailable.',
      ),
    },
    {
      value: 'pdf-text',
      label: pickLocaleText(locale, 'PDF 文本', 'PDF Text'),
      description: pickLocaleText(
        locale,
        '使用 pdf.js 提取 PDF 全文，适合没有 MinerU Markdown 的场景。',
        'Use pdf.js to extract full PDF text, suitable when MinerU Markdown is unavailable.',
      ),
    },
  ];
}

function buildQaSourceOptions(locale: UiLanguage): Array<{
  value: ReaderSettings['qaSourceMode'];
  label: string;
  description: string;
}> {
  return [
    {
      value: 'mineru-markdown',
      label: 'MinerU Markdown',
      description: pickLocaleText(
        locale,
        '优先使用 MinerU 结构化内容中的 Markdown 作为问答上下文。',
        'Prefer MinerU Markdown content as the QA context.',
      ),
    },
    {
      value: 'pdf-text',
      label: pickLocaleText(locale, 'PDF 文本', 'PDF Text'),
      description: pickLocaleText(
        locale,
        '使用 pdf.js 提取 PDF 全文作为问答上下文。',
        'Use full PDF text extracted by pdf.js as the QA context.',
      ),
    },
  ];
}

const DEFAULT_SETTINGS: ReaderSettings = {
  uiLanguage: 'zh-CN',
  autoLoadSiblingJson: false,
  autoMineruParse: false,
  autoGenerateSummary: false,
  libraryBatchConcurrency: 1,
  autoTranslateSelection: false,
  smoothScroll: true,
  compactReading: false,
  showBlockMeta: true,
  hidePageDecorationsInBlockView: false,
  softPageShadow: true,
  mineruCacheDir: '',
  remotePdfDownloadDir: '',
  translationBatchSize: 10,
  translationConcurrency: 1,
  translationBaseUrl: 'https://api.openai.com',
  translationModel: 'gpt-4o-mini',
  summaryBaseUrl: 'https://api.openai.com',
  summaryModel: 'gpt-4o-mini',
  translationModelPresetId: 'default',
  selectionTranslationModelPresetId: 'default',
  summaryModelPresetId: 'default',
  summarySourceMode: 'mineru-markdown',
  qaSourceMode: 'mineru-markdown',
  translationSourceLanguage: 'English',
  translationTargetLanguage: 'Chinese',
  translationDisplayMode: 'translated',
  qaActivePresetId: 'default',
};

const DEFAULT_QA_PRESET: QaModelPreset = {
  id: DEFAULT_QA_PRESET_ID,
  label: 'gpt-4o-mini',
  baseUrl: 'https://api.openai.com',
  apiKey: '',
  model: 'gpt-4o-mini',
  labelCustomized: false,
};

const DEFAULT_SECRETS: ReaderSecrets = {
  mineruApiToken: '',
  translationApiKey: '',
  summaryApiKey: '',
  zoteroApiKey: '',
  zoteroUserId: '',
  qaModelPresets: [DEFAULT_QA_PRESET],
};

function createQaPreset(partial?: Partial<QaModelPreset>): QaModelPreset {
  const nextModel = partial?.model ?? DEFAULT_QA_PRESET.model;
  const explicitLabel = typeof partial?.label === 'string' ? partial.label : undefined;
  const labelCustomized =
    partial?.labelCustomized ??
    (explicitLabel !== undefined &&
      explicitLabel.trim() !== '' &&
      explicitLabel.trim() !== nextModel.trim());
  const nextLabel =
    explicitLabel !== undefined
      ? explicitLabel || (!labelCustomized ? nextModel : '')
      : partial?.id === DEFAULT_QA_PRESET_ID
        ? DEFAULT_QA_PRESET.label
        : labelCustomized
          ? ''
          : nextModel;

  return {
    id: partial?.id?.trim() || `preset-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    label: nextLabel,
    baseUrl: partial?.baseUrl ?? DEFAULT_QA_PRESET.baseUrl,
    apiKey: partial?.apiKey ?? '',
    model: nextModel,
    labelCustomized,
  };
}

function getQaModelPresetKey(preset: QaModelPreset) {
  return `${preset.baseUrl.trim()}::${preset.model.trim()}::${preset.apiKey.trim()}`;
}

function getQaModelPresetScore(preset: QaModelPreset) {
  let score = 0;

  if (preset.baseUrl.trim()) {
    score += 1;
  }

  if (preset.model.trim()) {
    score += 1;
  }

  if (preset.apiKey.trim()) {
    score += 2;
  }

  if (preset.label.trim()) {
    score += 1;
  }

  if (preset.labelCustomized) {
    score += 1;
  }

  return score;
}

function isDefaultQaPresetPlaceholder(preset: QaModelPreset) {
  const normalizedLabel = preset.label.trim();

  return (
    !preset.apiKey.trim() &&
    preset.baseUrl.trim() === DEFAULT_QA_PRESET.baseUrl &&
    preset.model.trim() === DEFAULT_QA_PRESET.model &&
    (!preset.labelCustomized ||
      normalizedLabel === '' ||
      normalizedLabel === DEFAULT_QA_PRESET.label ||
      normalizedLabel === DEFAULT_QA_PRESET.model)
  );
}

function normalizeQaModelPresets(presets: unknown): QaModelPreset[] {
  if (!Array.isArray(presets)) {
    return [DEFAULT_QA_PRESET];
  }

  const normalized = presets
    .filter((preset): preset is Partial<QaModelPreset> => Boolean(preset && typeof preset === 'object'))
    .map((preset) => createQaPreset(preset));

  return normalized.length > 0 ? dedupeQaModelPresets(normalized) : [DEFAULT_QA_PRESET];
}

function dedupeQaModelPresets(presets: QaModelPreset[]): QaModelPreset[] {
  const bestById = new Map<string, QaModelPreset>();

  for (const preset of presets.map((item) => createQaPreset(item))) {
    const existing = bestById.get(preset.id);

    if (!existing || getQaModelPresetScore(preset) > getQaModelPresetScore(existing)) {
      bestById.set(preset.id, preset);
    }
  }

  const bestByKey = new Map<string, QaModelPreset>();

  for (const preset of bestById.values()) {
    const key = getQaModelPresetKey(preset);
    const existing = bestByKey.get(key);

    if (!existing || getQaModelPresetScore(preset) > getQaModelPresetScore(existing)) {
      bestByKey.set(key, preset);
    }
  }

  const normalized = Array.from(bestByKey.values());
  const filtered =
    normalized.length > 1
      ? normalized.filter((preset) => !isDefaultQaPresetPlaceholder(preset))
      : normalized;

  return filtered.length > 0 ? filtered.map((preset) => createQaPreset(preset)) : [DEFAULT_QA_PRESET];
}

function buildLegacyModelPresets(
  settings: Partial<ReaderSettings>,
  secrets: Partial<ReaderSecrets>,
): QaModelPreset[] {
  const presets = normalizeQaModelPresets(secrets.qaModelPresets);
  const existingKeys = new Set(
    presets.map((preset) => `${preset.baseUrl.trim()}::${preset.model.trim()}::${preset.apiKey.trim()}`),
  );
  const extras: QaModelPreset[] = [];

  if (
    settings.translationBaseUrl?.trim() ||
    settings.translationModel?.trim() ||
    secrets.translationApiKey?.trim()
  ) {
    const legacyTranslationPreset = createQaPreset({
      id: 'legacy-translation',
      label: settings.translationModel?.trim() || 'Document Translation',
      model: settings.translationModel?.trim() || DEFAULT_QA_PRESET.model,
      baseUrl: settings.translationBaseUrl?.trim() || DEFAULT_QA_PRESET.baseUrl,
      apiKey: secrets.translationApiKey?.trim() || '',
    });
    const translationKey = `${legacyTranslationPreset.baseUrl.trim()}::${legacyTranslationPreset.model.trim()}::${legacyTranslationPreset.apiKey.trim()}`;

    if (!existingKeys.has(translationKey)) {
      extras.push(legacyTranslationPreset);
      existingKeys.add(translationKey);
    }
  }

  if (
    settings.summaryBaseUrl?.trim() ||
    settings.summaryModel?.trim() ||
    secrets.summaryApiKey?.trim()
  ) {
    const legacySummaryPreset = createQaPreset({
      id: 'legacy-summary',
      label: settings.summaryModel?.trim() || 'Paper Summary',
      model: settings.summaryModel?.trim() || DEFAULT_QA_PRESET.model,
      baseUrl: settings.summaryBaseUrl?.trim() || DEFAULT_QA_PRESET.baseUrl,
      apiKey: secrets.summaryApiKey?.trim() || '',
    });
    const summaryKey = `${legacySummaryPreset.baseUrl.trim()}::${legacySummaryPreset.model.trim()}::${legacySummaryPreset.apiKey.trim()}`;

    if (!existingKeys.has(summaryKey)) {
      extras.push(legacySummaryPreset);
    }
  }

  return dedupeQaModelPresets([...presets, ...extras]);
}

function resolveModelPreset(
  presets: QaModelPreset[],
  presetId: string | undefined,
): QaModelPreset | null {
  return presets.find((preset) => preset.id === presetId) ?? presets[0] ?? null;
}

interface LibraryPreviewState {
  summary: PaperSummary | null;
  loading: boolean;
  error: string;
  hasBlocks: boolean;
  blockCount: number;
  currentPdfName: string;
  currentJsonName: string;
  statusMessage: string;
  sourceKey: string;
}

interface LibraryPreviewLoadResult {
  blocks: PositionedMineruBlock[];
  currentPdfName: string;
  currentJsonName: string;
  statusMessage: string;
  pdfPath?: string;
  markdownText?: string;
}

type LibraryPreviewOutcome = 'loaded' | 'generated' | 'skipped' | 'failed';

interface SummaryCacheEnvelope {
  version: number;
  sourceKey: string;
  summarizedAt: string;
  summary: PaperSummary;
}

interface BatchProgressState {
  running: boolean;
  paused: boolean;
  cancelRequested: boolean;
  total: number;
  completed: number;
  succeeded: number;
  skipped: number;
  failed: number;
  currentLabel: string;
}

interface MineruCacheManifest {
  version: number;
  documentKey: string;
  title: string;
  pdfPath: string;
  savedAt: string;
  sourceKind: 'cloud' | 'manual-json' | 'sibling-json';
  batchId?: string;
  dataId?: string;
  fileName?: string;
  zipEntries?: string[];
}

const EMPTY_LIBRARY_PREVIEW_STATE: LibraryPreviewState = {
  summary: null,
  loading: false,
  error: '',
  hasBlocks: false,
  blockCount: 0,
  currentPdfName: '',
  currentJsonName: '',
  statusMessage: '',
  sourceKey: '',
};

const EMPTY_BATCH_PROGRESS: BatchProgressState = {
  running: false,
  paused: false,
  cancelRequested: false,
  total: 0,
  completed: 0,
  succeeded: 0,
  skipped: 0,
  failed: 0,
  currentLabel: '',
};

function getAutoParseAttemptKey(item: WorkspaceItem): string {
  return `${item.workspaceId}::${item.localPdfPath?.trim() ?? ''}`;
}

function getAutoSummaryAttemptKey(
  item: WorkspaceItem,
  sourceMode: SummarySourceMode,
  hasParse: boolean,
): string {
  return `${item.workspaceId}::${sourceMode}::${item.localPdfPath?.trim() ?? ''}::${hasParse ? 'parsed' : 'unparsed'}`;
}

function clampBatchConcurrency(value: number): number {
  if (!Number.isFinite(value)) {
    return 1;
  }

  return Math.min(8, Math.max(1, Math.trunc(value)));
}

function getPathSeparator(path: string): string {
  return path.includes('\\') ? '\\' : '/';
}

function joinSystemPath(basePath: string, ...segments: string[]): string {
  const separator = getPathSeparator(basePath);
  const normalizedBase = basePath.replace(/[\\/]+$/, '');

  return [normalizedBase, ...segments.filter(Boolean)].join(separator);
}

function buildLegacyConfigPath(executableDir: string): string {
  return joinSystemPath(executableDir, 'paperquay-data', 'paperquay.config.json');
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => {
    window.setTimeout(resolve, ms);
  });
}

function clampTranslationBatchSize(value: number): number {
  if (!Number.isFinite(value)) {
    return DEFAULT_SETTINGS.translationBatchSize;
  }

  return Math.min(50, Math.max(1, Math.trunc(value)));
}

function clampTranslationConcurrency(value: number): number {
  if (!Number.isFinite(value)) {
    return DEFAULT_SETTINGS.translationConcurrency;
  }

  return Math.min(8, Math.max(1, Math.trunc(value)));
}

function normalizeReaderSettings(value?: Partial<ReaderSettings> | null): ReaderSettings {
  const merged = {
    ...DEFAULT_SETTINGS,
    ...(value ?? {}),
  };

  return {
    ...merged,
    uiLanguage: merged.uiLanguage === 'en-US' ? 'en-US' : 'zh-CN',
    libraryBatchConcurrency: clampBatchConcurrency(merged.libraryBatchConcurrency),
    translationBatchSize: clampTranslationBatchSize(merged.translationBatchSize),
    translationConcurrency: clampTranslationConcurrency(merged.translationConcurrency),
    translationDisplayMode: 'translated',
  };
}

function loadSettings(): ReaderSettings {
  try {
    const storedSettings = localStorage.getItem(SETTINGS_STORAGE_KEY);

    return storedSettings
      ? normalizeReaderSettings(JSON.parse(storedSettings) as Partial<ReaderSettings>)
      : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function loadSecrets(): ReaderSecrets {
  try {
    const storedSecrets = localStorage.getItem(SECRETS_STORAGE_KEY);

    if (!storedSecrets) {
      return DEFAULT_SECRETS;
    }

    const parsed = JSON.parse(storedSecrets) as Partial<ReaderSecrets>;

    return {
      ...DEFAULT_SECRETS,
      ...parsed,
      qaModelPresets: normalizeQaModelPresets(parsed.qaModelPresets),
    };
  } catch {
    return DEFAULT_SECRETS;
  }
}

function mergeReaderConfigWithDefaults(
  value: Partial<ReaderConfigFile> | null | undefined,
  fallbackSettings: ReaderSettings,
  fallbackSecrets: ReaderSecrets,
  defaultPaths: AppDefaultPaths,
): ReaderConfigFile {
  const nextSettings = normalizeReaderSettings({
    ...fallbackSettings,
    ...(value?.settings ?? {}),
  });
  const nextSecrets: ReaderSecrets = {
    ...DEFAULT_SECRETS,
    ...fallbackSecrets,
    ...(value?.secrets ?? {}),
    qaModelPresets: normalizeQaModelPresets(
      value?.secrets?.qaModelPresets ?? fallbackSecrets.qaModelPresets,
    ),
  };

  if (!nextSettings.mineruCacheDir.trim()) {
    nextSettings.mineruCacheDir = defaultPaths.mineruCacheDir;
  }

  if (!nextSettings.remotePdfDownloadDir.trim()) {
    nextSettings.remotePdfDownloadDir = defaultPaths.remotePdfDownloadDir;
  }

  return {
    version: value?.version ?? READER_CONFIG_VERSION,
    settings: nextSettings,
    secrets: nextSecrets,
    zoteroLocalDataDir: value?.zoteroLocalDataDir ?? '',
    leftSidebarCollapsed: value?.leftSidebarCollapsed ?? false,
  };
}

function loadStoredBoolean(key: string, fallback = false): boolean {
  try {
    const rawValue = localStorage.getItem(key);

    return rawValue === null ? fallback : rawValue === 'true';
  } catch {
    return fallback;
  }
}

function mergeLocalPdfPath<T extends { localPdfPath?: string }>(current: T, incoming: T): string | undefined {
  return Object.prototype.hasOwnProperty.call(incoming, 'localPdfPath')
    ? incoming.localPdfPath
    : current.localPdfPath;
}

function normalizeWorkspaceItem(
  item: ZoteroLibraryItem,
  source: WorkspaceItem['source'] = 'zotero-local',
): WorkspaceItem {
  const workspaceId =
    source === 'standalone'
      ? item.itemKey
      : `${item.itemKey}::${item.attachmentKey ?? item.localPdfPath ?? item.attachmentFilename ?? 'default'}`;

  return {
    ...item,
    source,
    workspaceId,
    groupKey: source === 'standalone' ? workspaceId : `zotero:${item.itemKey}`,
  };
}

function createStandaloneItem(path: string, locale: UiLanguage): WorkspaceItem {
  const filename = getFileNameFromPath(path);
  const title =
    filename.replace(/\.pdf$/i, '') || pickLocaleText(locale, '未命名 PDF', 'Untitled PDF');

  const workspaceId = `standalone:${path}`;

  return {
    itemKey: workspaceId,
    title,
    creators: pickLocaleText(locale, '独立 PDF', 'Standalone PDF'),
    year: '',
    itemType: 'pdf',
    localPdfPath: path,
    source: 'standalone',
    workspaceId,
    groupKey: workspaceId,
  };
}

function buildFlatCollections(collections: ZoteroCollection[]): FlatCollection[] {
  const grouped = new Map<string | null, ZoteroCollection[]>();
  const collectionMap = new Map(collections.map((collection) => [collection.collectionKey, collection]));

  for (const collection of collections) {
    const parentKey = collection.parentCollectionKey ?? null;
    const bucket = grouped.get(parentKey) ?? [];
    bucket.push(collection);
    grouped.set(parentKey, bucket);
  }

  const sortCollections = (items: ZoteroCollection[]) =>
    [...items].sort((left, right) => left.name.localeCompare(right.name, 'zh-CN'));

  const visited = new Set<string>();
  const output: FlatCollection[] = [];

  const walk = (parentKey: string | null, depth: number) => {
    for (const collection of sortCollections(grouped.get(parentKey) ?? [])) {
      visited.add(collection.collectionKey);
      output.push({
        ...collection,
        depth,
      });
      walk(collection.collectionKey, depth + 1);
    }
  };

  walk(null, 0);

  for (const collection of sortCollections(collections)) {
    if (visited.has(collection.collectionKey)) {
      continue;
    }

    const parentExists = collection.parentCollectionKey
      ? collectionMap.has(collection.parentCollectionKey)
      : false;

    output.push({
      ...collection,
      depth: parentExists ? 1 : 0,
    });
  }

  return output;
}

function matchesLibraryQuery(item: WorkspaceItem, query: string): boolean {
  if (!query.trim()) {
    return true;
  }

  const normalizedQuery = query.trim().toLowerCase();

  return [item.title, item.creators, item.year, item.attachmentFilename]
    .filter(Boolean)
    .some((value) => value!.toLowerCase().includes(normalizedQuery));
}

function ToggleRow({
  title,
  description,
  checked,
  onChange,
}: {
  title: string;
  description: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between gap-4 rounded-2xl border border-slate-200/80 bg-white/90 px-4 py-3 text-left shadow-[0_10px_24px_rgba(15,23,42,0.04)] transition-all duration-200 hover:border-slate-300 hover:bg-white"
    >
      <span className="min-w-0">
        <span className="block text-sm font-medium text-slate-900">{title}</span>
        <span className="mt-1 block text-xs leading-5 text-slate-500">{description}</span>
      </span>
      <span
        className={clsx(
          'relative h-6 w-11 shrink-0 rounded-full transition',
          checked ? 'bg-indigo-500' : 'bg-slate-300',
        )}
      >
        <span
          className={clsx(
            'absolute top-1 h-4 w-4 rounded-full bg-white shadow-sm transition',
            checked ? 'left-6' : 'left-1',
          )}
        />
      </span>
    </button>
  );
}

function ProgressBar({
  value,
  total,
  tone = 'indigo',
}: {
  value: number;
  total: number;
  tone?: 'indigo' | 'emerald';
}) {
  const ratio = total > 0 ? Math.min(100, Math.max(0, (value / total) * 100)) : 0;

  return (
    <div className="h-2 overflow-hidden rounded-full bg-slate-100">
      <div
        className={clsx(
          'h-full rounded-full transition-all duration-300',
          tone === 'emerald' ? 'bg-emerald-500' : 'bg-indigo-500',
        )}
        style={{ width: `${ratio}%` }}
      />
    </div>
  );
}

function BatchProgressCard({
  title,
  progress,
  tone = 'indigo',
}: {
  title: string;
  progress: BatchProgressState;
  tone?: 'indigo' | 'emerald';
}) {
  const locale = useAppLocale();
  if (!progress.running && progress.total === 0) {
    return null;
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50/80 px-4 py-3">
      <div className="flex items-center justify-between gap-3 text-sm">
        <div className="font-medium text-slate-900">{title}</div>
        <div className="text-slate-500">
          {progress.completed}/{progress.total}
        </div>
      </div>
      <div className="mt-3">
        <ProgressBar value={progress.completed} total={progress.total} tone={tone} />
      </div>
      <div className="mt-2 flex flex-wrap gap-3 text-xs text-slate-500">
        <span>{pickLocaleText(locale, `成功 ${progress.succeeded}`, `Succeeded ${progress.succeeded}`)}</span>
        <span>{pickLocaleText(locale, `跳过 ${progress.skipped}`, `Skipped ${progress.skipped}`)}</span>
        <span>{pickLocaleText(locale, `失败 ${progress.failed}`, `Failed ${progress.failed}`)}</span>
        {progress.paused ? (
          <span>{pickLocaleText(locale, '已暂停', 'Paused')}</span>
        ) : null}
        {progress.cancelRequested ? (
          <span>{pickLocaleText(locale, '取消中', 'Cancelling')}</span>
        ) : null}
      </div>
      {progress.currentLabel ? (
        <div className="mt-2 truncate text-xs text-slate-500">{progress.currentLabel}</div>
      ) : null}
    </div>
  );
}

interface PreferencesWindowProps {
  open: boolean;
  onClose: () => void;
  settings: ReaderSettings;
  zoteroLocalDataDir: string;
  mineruApiToken: string;
  translationApiKey: string;
  summaryApiKey: string;
  qaModelPresets: QaModelPreset[];
  zoteroApiKey: string;
  zoteroUserId: string;
  libraryLoading: boolean;
  translating?: boolean;
  translatedCount?: number;
  onSettingChange: <Key extends keyof ReaderSettings>(
    key: Key,
    value: ReaderSettings[Key],
  ) => void;
  onZoteroLocalDataDirChange: (value: string) => void;
  onMineruApiTokenChange: (value: string) => void;
  onTranslationApiKeyChange: (value: string) => void;
  onSummaryApiKeyChange: (value: string) => void;
  onZoteroApiKeyChange: (value: string) => void;
  onZoteroUserIdChange: (value: string) => void;
  onDetectLocalZotero: () => void;
  onSelectLocalZoteroDir: () => void;
  onReloadLocalZotero: () => void;
  onSelectMineruCacheDir: () => void;
  onSelectRemotePdfDownloadDir: () => void;
  onTestLlmConnection: (preset?: QaModelPreset) => Promise<OpenAICompatibleTestResult>;
  onQaModelPresetAdd: () => void;
  onQaModelPresetRemove: (presetId: string) => void;
  onQaModelPresetChange: (presetId: string, patch: Partial<QaModelPreset>) => void;
  onTranslate?: (() => void) | null;
  onClearTranslations?: (() => void) | null;
  onBatchMineruParse: () => void;
  onBatchGenerateSummaries: () => void;
  onToggleBatchMineruPause: () => void;
  onCancelBatchMineru: () => void;
  onToggleBatchSummaryPause: () => void;
  onCancelBatchSummary: () => void;
  batchMineruRunning?: boolean;
  batchSummaryRunning?: boolean;
  batchMineruPaused?: boolean;
  batchSummaryPaused?: boolean;
  batchMineruProgress: BatchProgressState;
  batchSummaryProgress: BatchProgressState;
}
function SettingsField({
  label,
  description,
  children,
}: {
  label: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <div className="space-y-2 rounded-2xl border border-slate-200 bg-white p-4 shadow-[0_8px_24px_rgba(15,23,42,0.04)]">
      <div>
        <div className="text-sm font-medium text-slate-900">{label}</div>
        {description ? <div className="mt-1 text-xs leading-5 text-slate-500">{description}</div> : null}
      </div>
      {children}
    </div>
  );
}

function SettingsInput(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={clsx(
        'w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 outline-none transition focus:border-indigo-300 focus:bg-white',
        props.className,
      )}
    />
  );
}

function SettingsSelect(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={clsx(
        'w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 outline-none transition focus:border-indigo-300 focus:bg-white',
        props.className,
      )}
    />
  );
}

function PreferencesWindow({
  open,
  onClose,
  settings,
  zoteroLocalDataDir,
  mineruApiToken,
  translationApiKey,
  summaryApiKey,
  qaModelPresets,
  zoteroApiKey,
  zoteroUserId,
  libraryLoading,
  translating = false,
  translatedCount = 0,
  onSettingChange,
  onZoteroLocalDataDirChange,
  onMineruApiTokenChange,
  onTranslationApiKeyChange,
  onSummaryApiKeyChange,
  onZoteroApiKeyChange,
  onZoteroUserIdChange,
  onDetectLocalZotero,
  onSelectLocalZoteroDir,
  onReloadLocalZotero,
  onSelectMineruCacheDir,
  onSelectRemotePdfDownloadDir,
  onTestLlmConnection,
  onQaModelPresetAdd,
  onQaModelPresetRemove,
  onQaModelPresetChange,
  onTranslate,
  onClearTranslations,
  onBatchMineruParse,
  onBatchGenerateSummaries,
  onToggleBatchMineruPause,
  onCancelBatchMineru,
  onToggleBatchSummaryPause,
  onCancelBatchSummary,
  batchMineruRunning = false,
  batchSummaryRunning = false,
  batchMineruPaused = false,
  batchSummaryPaused = false,
  batchMineruProgress,
  batchSummaryProgress,
}: PreferencesWindowProps) {
  const uiLanguage = settings.uiLanguage;
  const l = <T,>(zh: T, en: T) => pickLocaleText(uiLanguage, zh, en);
  const languageOptions = buildLanguageOptions(uiLanguage);
  const summarySourceOptions = buildSummarySourceOptions(uiLanguage);
  const qaSourceOptions = buildQaSourceOptions(uiLanguage);
  const [activeSection, setActiveSection] = useState<
    'library' | 'reading' | 'mineru' | 'translation'
  >('library');
  const [llmTestLoading, setLlmTestLoading] = useState(false);
  const [llmTestResult, setLlmTestResult] = useState<OpenAICompatibleTestResult | null>(null);
  const [presetTestLoadingMap, setPresetTestLoadingMap] = useState<Record<string, boolean>>({});
  const [presetTestResultMap, setPresetTestResultMap] = useState<
    Record<string, OpenAICompatibleTestResult | null>
  >({});
  const activeTranslationPreset = resolveModelPreset(
    qaModelPresets,
    settings.translationModelPresetId,
  );
  const activeSelectionTranslationPreset = resolveModelPreset(
    qaModelPresets,
    settings.selectionTranslationModelPresetId,
  );
  const activeSummaryPreset = resolveModelPreset(
    qaModelPresets,
    settings.summaryModelPresetId,
  );

  useEffect(() => {
    if (!open) {
      return undefined;
    }

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose, open]);

  if (!open) {
    return null;
  }

  const canTriggerTranslate = Boolean(onTranslate);
  const canClearTranslations = Boolean(onClearTranslations);
  const canTestLlm = Boolean(
    activeTranslationPreset?.baseUrl.trim() &&
      activeTranslationPreset?.model.trim() &&
      activeTranslationPreset?.apiKey.trim(),
  );
  const handleTestLlmConnection = async () => {
    setLlmTestLoading(true);
    setLlmTestResult(null);

    try {
      const result = await onTestLlmConnection();
      setLlmTestResult(result);
    } catch (nextError) {
      setLlmTestResult({
        ok: false,
        endpoint: settings.translationBaseUrl.trim(),
        model: settings.translationModel.trim(),
        latencyMs: 0,
        message: nextError instanceof Error ? nextError.message : l('测试连接失败', 'Connection test failed'),
      });
    } finally {
      setLlmTestLoading(false);
    }
  };

  const handleTestModelPreset = async (preset: QaModelPreset) => {
    setPresetTestLoadingMap((current) => ({
      ...current,
      [preset.id]: true,
    }));
    setPresetTestResultMap((current) => ({
      ...current,
      [preset.id]: null,
    }));

    try {
      const result = await onTestLlmConnection(preset);
      setPresetTestResultMap((current) => ({
        ...current,
        [preset.id]: result,
      }));
    } catch (nextError) {
      setPresetTestResultMap((current) => ({
        ...current,
        [preset.id]: {
          ok: false,
          endpoint: preset.baseUrl.trim(),
          model: preset.model.trim(),
          latencyMs: 0,
          message: nextError instanceof Error ? nextError.message : l('模型测试失败', 'Model test failed'),
        },
      }));
    } finally {
      setPresetTestLoadingMap((current) => ({
        ...current,
        [preset.id]: false,
      }));
    }
  };

  const sections = [
    {
      key: 'library' as const,
      title: l('本地库与 Zotero', 'Library & Zotero'),
      description: l('配置本地 Zotero 数据目录与回退能力', 'Configure local Zotero data and fallback behavior'),
      icon: <Library className="h-4 w-4" strokeWidth={1.8} />,
    },
    {
      key: 'reading' as const,
      title: l('阅读体验', 'Reading'),
      description: l('控制联动、滚动、版式与显示细节', 'Control linkage, scrolling, layout, and display details'),
      icon: <BookOpenText className="h-4 w-4" strokeWidth={1.8} />,
    },
    {
      key: 'mineru' as const,
      title: 'MinerU',
      description: l('管理解析缓存与批量处理能力', 'Manage parse cache and batch processing'),
      icon: <Database className="h-4 w-4" strokeWidth={1.8} />,
    },
    {
      key: 'translation' as const,
      title: l('翻译与 AI', 'Translation & AI'),
      description: l('配置模型、语言和连接测试', 'Configure models, languages, and connection tests'),
      icon: <Sparkles className="h-4 w-4" strokeWidth={1.8} />,
    },
  ];

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-950/28 backdrop-blur-sm">
      <button
        type="button"
        aria-label={l('关闭设置窗口', 'Close settings window')}
        className="absolute inset-0 cursor-default"
        onClick={onClose}
      />

      <div className="relative flex h-[min(760px,calc(100vh-32px))] w-[min(1080px,calc(100vw-32px))] overflow-hidden rounded-[30px] border border-slate-200/80 bg-[linear-gradient(180deg,#f8fafc,#f1f5f9)] shadow-[0_36px_120px_rgba(15,23,42,0.20)]">
        <aside className="flex w-64 shrink-0 flex-col border-r border-slate-200/80 bg-white/76 px-4 py-4 backdrop-blur-xl">
          <div className="px-3 pb-4">
            <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
              {l('设置', 'Settings')}
            </div>
            <div className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">
              {l('设置', 'Settings')}
            </div>
            <div className="mt-2 text-sm leading-6 text-slate-500">
              {l(
                '像桌面应用一样管理文库、阅读、解析与模型能力。',
                'Manage library, reading, parsing, and model capabilities in a desktop-first workflow.',
              )}
            </div>
          </div>

          <div className="space-y-1">
            {sections.map((section) => (
              <button
                key={section.key}
                type="button"
                onClick={() => setActiveSection(section.key)}
                className={clsx(
                  'flex w-full items-start gap-3 rounded-2xl px-3 py-3 text-left transition-all duration-200',
                  activeSection === section.key
                    ? 'bg-slate-900 text-white shadow-[0_12px_28px_rgba(15,23,42,0.18)]'
                    : 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-900',
                )}
              >
                <span className={clsx('mt-0.5', activeSection === section.key ? 'text-white' : 'text-slate-400')}>
                  {section.icon}
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-medium">{section.title}</span>
                  <span
                    className={clsx(
                      'mt-1 block text-xs leading-5',
                      activeSection === section.key ? 'text-white/72' : 'text-slate-400',
                    )}
                  >
                    {section.description}
                  </span>
                </span>
              </button>
            ))}
          </div>

          <div className="mt-auto rounded-2xl border border-slate-200 bg-white/80 p-3 text-xs leading-5 text-slate-500">
            {l(
              `当前翻译缓存：${translatedCount} 个结构块`,
              `Translation cache: ${translatedCount} blocks`,
            )}
          </div>
        </aside>

        <section className="flex min-w-0 flex-1 flex-col">
          <header className="flex items-center justify-between border-b border-slate-200/80 bg-white/70 px-6 py-4 backdrop-blur-xl">
            <div>
              <div className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-400">
                {sections.find((section) => section.key === activeSection)?.title}
              </div>
              <div className="mt-1 text-lg font-semibold text-slate-950">
                {sections.find((section) => section.key === activeSection)?.description}
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 transition-all duration-200 hover:bg-slate-50"
            >
              <X className="mr-2 h-4 w-4" strokeWidth={1.8} />
              {l('关闭', 'Close')}
            </button>
          </header>

          <div className="min-h-0 flex-1 overflow-y-auto px-6 py-6">
            <div className="mx-auto max-w-3xl space-y-4">
              <SettingsField
                label={l('软件语言', 'Software Language')}
                description={l('切换后，主界面与设置界面会同步切换中英文。', 'Switch the main interface and settings between Chinese and English.')}
              >
                <SettingsSelect
                  value={settings.uiLanguage}
                  onChange={(event) =>
                    onSettingChange('uiLanguage', event.target.value as ReaderSettings['uiLanguage'])
                  }
                >
                  <option value="zh-CN">简体中文</option>
                  <option value="en-US">English</option>
                </SettingsSelect>
              </SettingsField>
              {activeSection === 'library' ? (
                <>
                  <SettingsField
                    label={l('Zotero 本地数据目录', 'Zotero Local Data Directory')}
                    description={l(
                      '用于读取 Zotero 附件与分类树，目录中应包含 zotero.sqlite。',
                      'Used to read Zotero attachments and collection trees. The directory should contain zotero.sqlite.',
                    )}
                  >
                    <SettingsInput
                      value={zoteroLocalDataDir}
                      onChange={(event) => onZoteroLocalDataDirChange(event.target.value)}
                      placeholder={l('例如 C:\\Users\\Lenovo\\Zotero', 'Example: C:\\Users\\Lenovo\\Zotero')}
                    />
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={onDetectLocalZotero}
                        disabled={libraryLoading}
                        className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-100 disabled:opacity-60"
                      >
                        {l('自动查找', 'Auto Detect')}
                      </button>
                      <button
                        type="button"
                        onClick={onSelectLocalZoteroDir}
                        disabled={libraryLoading}
                        className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-100 disabled:opacity-60"
                      >
                        {l('选择目录', 'Select Directory')}
                      </button>
                      <button
                        type="button"
                        onClick={onReloadLocalZotero}
                        disabled={libraryLoading}
                        className="rounded-xl bg-slate-900 px-3 py-2 text-sm font-medium text-white transition hover:bg-slate-800 disabled:opacity-60"
                      >
                        {l('重新读取', 'Reload')}
                      </button>
                    </div>
                  </SettingsField>

                  <SettingsField
                    label={l('Zotero Web 回退', 'Zotero Web Fallback')}
                    description={l(
                      '当本地 PDF 缺失时，通过 Zotero Web API 回退获取附件。',
                      'When the local PDF is missing, fetch the attachment through the Zotero Web API fallback.',
                    )}
                  >
                    <div className="grid gap-3 md:grid-cols-2">
                      <div className="space-y-2">
                        <div className="text-xs font-medium text-slate-500">API Key</div>
                        <SettingsInput
                          value={zoteroApiKey}
                          onChange={(event) => onZoteroApiKeyChange(event.target.value)}
                          type="password"
                          placeholder={l(
                            '仅在本地 PDF 缺失时填写 API Key',
                            'Only required when the local PDF is missing.',
                          )}
                        />
                      </div>
                      <div className="space-y-2">
                        <div className="text-xs font-medium text-slate-500">User ID</div>
                        <SettingsInput
                          value={zoteroUserId}
                          onChange={(event) => onZoteroUserIdChange(event.target.value)}
                          placeholder={l('可留空，首次回退时自动获取', 'Optional. Auto-detected on first fallback.')}
                        />
                      </div>
                    </div>
                  </SettingsField>

                  <SettingsField
                    label={l('远程 PDF 下载目录', 'Remote PDF Download Directory')}
                    description={l(
                      '当通过 Zotero Web 获取 PDF 时，保存到此目录。',
                      'When downloading PDFs through Zotero Web, save them to this directory.',
                    )}
                  >
                    <SettingsInput
                      value={settings.remotePdfDownloadDir}
                      onChange={(event) =>
                        onSettingChange('remotePdfDownloadDir', event.target.value)
                      }
                      placeholder={l('选择本地目录保存下载的 PDF', 'Choose a local directory for downloaded PDFs')}
                    />
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={onSelectRemotePdfDownloadDir}
                        className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-100"
                      >
                        <FolderOpen className="mr-2 inline h-4 w-4" strokeWidth={1.8} />
                        {l('选择目录', 'Select Directory')}
                      </button>
                      <button
                        type="button"
                        onClick={() => onSettingChange('remotePdfDownloadDir', '')}
                        className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-100"
                      >
                        {l('清空路径', 'Clear Path')}
                      </button>
                    </div>
                  </SettingsField>

                  <SettingsField
                    label={l('文库自动处理', 'Library Automation')}
                    description={l(
                      '控制启动后是否自动执行 MinerU 解析和摘要生成。',
                      'Control whether MinerU parsing and summary generation run automatically after startup.',
                    )}
                  >
                    <div className="space-y-3">
                      <div className="grid gap-3 md:grid-cols-[minmax(0,1fr)_140px]">
                        <div className="rounded-2xl border border-slate-200 bg-white px-4 py-3">
                          <div className="text-sm font-medium text-slate-900">
                            {l('并发数配置', 'Concurrency')}
                          </div>
                          <div className="mt-1 text-xs leading-5 text-slate-500">
                            {l(
                              '控制批处理并发度，数值过高可能导致限流或性能波动。',
                              'Controls batch concurrency. Values that are too high may cause rate limits or unstable performance.',
                            )}
                          </div>
                        </div>
                        <SettingsInput
                          type="number"
                          min={1}
                          max={8}
                          step={1}
                          value={String(settings.libraryBatchConcurrency)}
                          onChange={(event) =>
                            onSettingChange(
                              'libraryBatchConcurrency',
                              clampBatchConcurrency(Number(event.target.value)),
                            )
                          }
                        />
                      </div>
                      <ToggleRow
                        title={l('自动执行 MinerU 解析', 'Auto Run MinerU Parse')}
                        description={l(
                          '检测到可处理 PDF 时自动触发 MinerU 解析。',
                          'Automatically trigger MinerU parsing when a processable PDF is detected.',
                        )}
                        checked={settings.autoMineruParse}
                        onChange={(checked) => onSettingChange('autoMineruParse', checked)}
                      />
                      <ToggleRow
                        title={l('自动生成摘要', 'Auto Generate Summary')}
                        description={l(
                          '检测到结构化内容后自动生成摘要预览。',
                          'Automatically generate a summary preview once structured content is available.',
                        )}
                        checked={settings.autoGenerateSummary}
                        onChange={(checked) => onSettingChange('autoGenerateSummary', checked)}
                      />
                      <div className="flex flex-wrap gap-2">
                        <button
                          type="button"
                          onClick={onBatchMineruParse}
                          disabled={batchMineruRunning}
                          className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800 disabled:opacity-60"
                        >
                          {batchMineruRunning
                            ? l('处理中...', 'Processing...')
                            : l('启动 MinerU 批量解析', 'Start MinerU Batch Parse')}
                        </button>
                        {batchMineruRunning ? (
                          <button
                            type="button"
                            onClick={onToggleBatchMineruPause}
                            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-700 transition hover:bg-slate-50"
                          >
                            {batchMineruPaused ? l('继续', 'Resume') : l('暂停', 'Pause')}
                          </button>
                        ) : null}
                        {batchMineruRunning ? (
                          <button
                            type="button"
                            onClick={onCancelBatchMineru}
                            className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-2 text-sm text-rose-600 transition hover:bg-rose-100"
                          >
                            {l('取消', 'Cancel')}
                          </button>
                        ) : null}
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <button
                          type="button"
                          onClick={onBatchGenerateSummaries}
                          disabled={batchSummaryRunning}
                          className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 text-sm text-slate-700 transition hover:bg-slate-100 disabled:opacity-60"
                        >
                          {batchSummaryRunning
                            ? l('处理中...', 'Processing...')
                            : l('全部生成摘要', 'Generate All Summaries')}
                        </button>
                        {batchSummaryRunning ? (
                          <button
                            type="button"
                            onClick={onToggleBatchSummaryPause}
                            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-700 transition hover:bg-slate-50"
                          >
                            {batchSummaryPaused ? l('继续', 'Resume') : l('暂停', 'Pause')}
                          </button>
                        ) : null}
                        {batchSummaryRunning ? (
                          <button
                            type="button"
                            onClick={onCancelBatchSummary}
                            className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-2 text-sm text-rose-600 transition hover:bg-rose-100"
                          >
                            {l('取消', 'Cancel')}
                          </button>
                        ) : null}
                      </div>
                      <BatchProgressCard
                        title={l('MinerU 批量解析进度', 'MinerU Batch Progress')}
                        progress={batchMineruProgress}
                        tone="indigo"
                      />
                      <BatchProgressCard
                        title={l('批量摘要生成进度', 'Batch Summary Progress')}
                        progress={batchSummaryProgress}
                        tone="emerald"
                      />
                    </div>
                  </SettingsField>
                </>
              ) : null}

              {activeSection === 'reading' ? (
                <>
                  <ToggleRow
                    title={l('自动加载同名 JSON', 'Auto Load Sibling JSON')}
                    description={l(
                      '打开 PDF 时，自动尝试加载同目录下对应的 content_list_v2.json。',
                      'When opening a PDF, automatically try to load the matching content_list_v2.json from the same directory.',
                    )}
                    checked={settings.autoLoadSiblingJson}
                    onChange={(checked) => onSettingChange('autoLoadSiblingJson', checked)}
                  />
                  <ToggleRow
                    title={l('平滑滚动联动', 'Smooth Linked Scrolling')}
                    description={l(
                      '在 PDF 与结构块之间联动时，使用更平滑的滚动定位。',
                      'Use smoother scrolling when navigating between the PDF and structured blocks.',
                    )}
                    checked={settings.smoothScroll}
                    onChange={(checked) => onSettingChange('smoothScroll', checked)}
                  />
                  <ToggleRow
                    title={l('紧凑阅读模式', 'Compact Reading Mode')}
                    description={l(
                      '压缩结构块列表的间距，适合长文快速通读。',
                      'Reduce block spacing for faster reading in long documents.',
                    )}
                    checked={settings.compactReading}
                    onChange={(checked) => onSettingChange('compactReading', checked)}
                  />
                  <ToggleRow
                    title={l('显示块元信息', 'Show Block Metadata')}
                    description={l(
                      '在结构块中显示页码、类型等辅助信息。',
                      'Show page numbers, block types, and related metadata in the block view.',
                    )}
                    checked={settings.showBlockMeta}
                    onChange={(checked) => onSettingChange('showBlockMeta', checked)}
                  />
                  <ToggleRow
                    title={l('隐藏页眉页脚类块', 'Hide Page Decoration Blocks')}
                    description={l(
                      '在右侧结构块视图中隐藏 page_number、page_footer 等页面装饰内容。',
                      'Hide page_number, page_footer, and similar decorative content from the block view.',
                    )}
                    checked={settings.hidePageDecorationsInBlockView}
                    onChange={(checked) =>
                      onSettingChange('hidePageDecorationsInBlockView', checked)
                    }
                  />
                  <ToggleRow
                    title={l('柔和页面阴影', 'Soft Page Shadow')}
                    description={l(
                      '为 PDF 页面添加更轻的阴影层次。',
                      'Render PDF pages with a softer shadow treatment.',
                    )}
                    checked={settings.softPageShadow}
                    onChange={(checked) => onSettingChange('softPageShadow', checked)}
                  />
                </>
              ) : null}

              {activeSection === 'mineru' ? (
                <>
                  <SettingsField
                    label="MinerU API Token"
                    description={l(
                      '配置后可将本地 PDF 发送给 MinerU 并生成结构化 JSON。',
                      'Configure this to send local PDFs to MinerU and generate structured JSON.',
                    )}
                  >
                    <SettingsInput
                      value={mineruApiToken}
                      onChange={(event) => onMineruApiTokenChange(event.target.value)}
                      type="password"
                      placeholder={l('输入 MinerU API Token', 'Enter MinerU API Token')}
                    />
                  </SettingsField>

                  <SettingsField
                    label={l('MinerU 缓存目录', 'MinerU Cache Directory')}
                    description={l(
                      '用于保存 content_list_v2.json、middle.json、full.md 与 manifest 等解析产物。',
                      'Stores content_list_v2.json, middle.json, full.md, manifest, and related parse outputs.',
                    )}
                  >
                    <SettingsInput
                      value={settings.mineruCacheDir}
                      onChange={(event) => onSettingChange('mineruCacheDir', event.target.value)}
                      placeholder={l(
                        '选择一个本地目录保存 MinerU 结果',
                        'Choose a local directory to store MinerU outputs',
                      )}
                    />
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={onSelectMineruCacheDir}
                        className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-100"
                      >
                        <FolderOpen className="mr-2 inline h-4 w-4" strokeWidth={1.8} />
                        {l('选择目录', 'Select Directory')}
                      </button>
                      <button
                        type="button"
                        onClick={() => onSettingChange('mineruCacheDir', '')}
                        className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-100"
                      >
                        {l('清空路径', 'Clear Path')}
                      </button>
                    </div>
                  </SettingsField>
                </>
              ) : null}

              {activeSection === 'translation' ? (
                <>
                  <SettingsField
                    label={l('模型预设库', 'Model Presets')}
                    description={l(
                      '统一维护翻译、摘要与问答共用的 OpenAI 兼容模型配置。',
                      'Maintain shared OpenAI-compatible model configurations for translation, summary, and QA.',
                    )}
                  >
                    <div className="space-y-3">
                      {qaModelPresets.map((preset) => (
                        <div
                          key={preset.id}
                          className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4"
                        >
                          <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
                            <div className="text-sm font-medium text-slate-900">
                              {preset.label || preset.model || l('未命名模型', 'Unnamed Preset')}
                            </div>
                            <button
                              type="button"
                              onClick={() => void handleTestModelPreset(preset)}
                              disabled={
                                !preset.baseUrl.trim() ||
                                !preset.model.trim() ||
                                !preset.apiKey.trim() ||
                                Boolean(presetTestLoadingMap[preset.id])
                              }
                              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-100 disabled:opacity-50"
                            >
                              {presetTestLoadingMap[preset.id]
                                ? l('测试中...', 'Testing...')
                                : l('测试', 'Test')}
                            </button>
                            <button
                              type="button"
                              onClick={() => onQaModelPresetRemove(preset.id)}
                              disabled={qaModelPresets.length <= 1}
                              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-100 disabled:opacity-50"
                            >
                              {l('删除', 'Delete')}
                            </button>
                          </div>

                          <div className="grid gap-3 md:grid-cols-2">
                            <div className="space-y-2">
                              <div className="text-xs font-medium text-slate-500">
                                {l('显示名称', 'Display Name')}
                              </div>
                              <SettingsInput
                                value={preset.label}
                                onChange={(event) =>
                                  onQaModelPresetChange(preset.id, { label: event.target.value })
                                }
                                placeholder={l(
                                  '例如：DeepSeek Chat',
                                  'Example: DeepSeek Chat',
                                )}
                              />
                            </div>
                            <div className="space-y-2">
                              <div className="text-xs font-medium text-slate-500">
                                {l('模型名称', 'Model Name')}
                              </div>
                              <SettingsInput
                                value={preset.model}
                                onChange={(event) =>
                                  onQaModelPresetChange(preset.id, { model: event.target.value })
                                }
                                placeholder="gpt-4o-mini / deepseek-chat / qwen-plus"
                              />
                            </div>
                            <div className="space-y-2 md:col-span-2">
                              <div className="text-xs font-medium text-slate-500">
                                {l('地址', 'Endpoint')}
                              </div>
                              <SettingsInput
                                value={preset.baseUrl}
                                onChange={(event) =>
                                  onQaModelPresetChange(preset.id, { baseUrl: event.target.value })
                                }
                                placeholder="https://api.openai.com"
                              />
                            </div>
                            <div className="space-y-2 md:col-span-2">
                              <div className="text-xs font-medium text-slate-500">API Key</div>
                              <SettingsInput
                                value={preset.apiKey}
                                onChange={(event) =>
                                  onQaModelPresetChange(preset.id, { apiKey: event.target.value })
                                }
                                type="password"
                                placeholder={l(
                                  '输入该模型预设的 API Key',
                                  'Enter the API key for this preset',
                                )}
                              />
                            </div>
                          </div>

                            {!preset.baseUrl.trim() ||
                            !preset.model.trim() ||
                            !preset.apiKey.trim() ? (
                              <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs leading-5 text-amber-700">
                                {l(
                                  'Base URL、模型名称和 API Key 需要同时填写，才能用于测试与调用。',
                                  'Fill in the Base URL, model name, and API key before testing or using this preset.',
                                )}
                              </div>
                            ) : null}

                          {presetTestResultMap[preset.id] ? (
                            <div
                              className={clsx(
                                'mt-3 rounded-xl border px-3 py-2 text-xs leading-5',
                                presetTestResultMap[preset.id]?.ok
                                  ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                                  : 'border-rose-200 bg-rose-50 text-rose-700',
                              )}
                            >
                              <div className="font-medium">
                                {presetTestResultMap[preset.id]?.ok
                                  ? l('连接成功', 'Connection Succeeded')
                                  : l('连接失败', 'Connection Failed')}
                                {presetTestResultMap[preset.id]?.latencyMs
                                  ? ` · ${presetTestResultMap[preset.id]!.latencyMs} ms`
                                  : ''}
                              </div>
                              <div className="mt-1 break-all">
                                {l('地址', 'Endpoint')}:{' '}
                                {presetTestResultMap[preset.id]?.endpoint ||
                                  l('未返回', 'Unavailable')}
                              </div>
                              <div className="mt-1 break-all">
                                {l('模型', 'Model')}:{' '}
                                {presetTestResultMap[preset.id]?.responseModel ||
                                  presetTestResultMap[preset.id]?.model ||
                                  l('未返回', 'Unavailable')}
                              </div>
                              <div className="mt-1 whitespace-pre-wrap">
                                {presetTestResultMap[preset.id]?.message}
                              </div>
                            </div>
                          ) : null}
                        </div>
                      ))}

                      <button
                        type="button"
                        onClick={onQaModelPresetAdd}
                        className="rounded-xl border border-dashed border-slate-300 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:border-slate-400 hover:bg-slate-50"
                      >
                        {l('新增模型预设', 'Add Model Preset')}
                      </button>
                    </div>
                  </SettingsField>

                  <SettingsField
                    label={l('问答上下文来源', 'QA Context Source')}
                    description={l(
                      '控制问答时优先使用 MinerU Markdown 还是 PDF 文本。',
                      'Choose whether QA should prefer MinerU Markdown or extracted PDF text.',
                    )}
                  >
                    <div className="grid gap-2">
                      {qaSourceOptions.map((option) => (
                        <button
                          key={option.value}
                          type="button"
                          onClick={() => onSettingChange('qaSourceMode', option.value)}
                          className={clsx(
                            'rounded-2xl border px-4 py-3 text-left transition',
                            settings.qaSourceMode === option.value
                              ? 'border-indigo-200 bg-indigo-50/80 text-indigo-700'
                              : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-slate-300 hover:bg-white',
                          )}
                        >
                          <div className="text-sm font-medium">{option.label}</div>
                          <div className="mt-1 text-xs leading-5 text-slate-500">
                            {option.description}
                          </div>
                        </button>
                      ))}
                    </div>
                  </SettingsField>

                  <SettingsField
                    label={l('功能角色绑定', 'Feature Role Binding')}
                    description={l(
                      '为文档翻译、划词翻译、摘要与问答分别选择默认模型。',
                      'Choose default presets for document translation, selection translation, summary, and QA.',
                    )}
                  >
                    <div className="grid gap-3 md:grid-cols-2">
                      <div className="space-y-2">
                        <div className="text-xs font-medium text-slate-500">
                          {l('文档翻译', 'Document Translation')}
                        </div>
                        <SettingsSelect
                          value={settings.translationModelPresetId}
                          onChange={(event) =>
                            onSettingChange('translationModelPresetId', event.target.value)
                          }
                        >
                          {qaModelPresets.map((preset) => (
                            <option key={preset.id} value={preset.id}>
                              {preset.label || preset.model}
                            </option>
                          ))}
                        </SettingsSelect>
                      </div>
                      <div className="space-y-2">
                        <div className="text-xs font-medium text-slate-500">
                          {l('划词翻译', 'Selection Translation')}
                        </div>
                        <SettingsSelect
                          value={settings.selectionTranslationModelPresetId}
                          onChange={(event) =>
                            onSettingChange('selectionTranslationModelPresetId', event.target.value)
                          }
                        >
                          {qaModelPresets.map((preset) => (
                            <option key={preset.id} value={preset.id}>
                              {preset.label || preset.model}
                            </option>
                          ))}
                        </SettingsSelect>
                      </div>
                      <div className="space-y-2">
                        <div className="text-xs font-medium text-slate-500">
                          {l('论文摘要', 'Paper Summary')}
                        </div>
                        <SettingsSelect
                          value={settings.summaryModelPresetId}
                          onChange={(event) =>
                            onSettingChange('summaryModelPresetId', event.target.value)
                          }
                        >
                          {qaModelPresets.map((preset) => (
                            <option key={preset.id} value={preset.id}>
                              {preset.label || preset.model}
                            </option>
                          ))}
                        </SettingsSelect>
                      </div>
                      <div className="space-y-2">
                        <div className="text-xs font-medium text-slate-500">
                          {l('问答默认模型', 'Default QA Model')}
                        </div>
                        <SettingsSelect
                          value={settings.qaActivePresetId}
                          onChange={(event) => onSettingChange('qaActivePresetId', event.target.value)}
                        >
                          {qaModelPresets.map((preset) => (
                            <option key={preset.id} value={preset.id}>
                              {preset.label || preset.model}
                            </option>
                          ))}
                        </SettingsSelect>
                      </div>
                    </div>
                  </SettingsField>

                  <SettingsField
                    label={l('翻译吞吐配置', 'Translation Throughput')}
                    description={l(
                      '控制整篇翻译时每批块数与并发数。',
                      'Control batch size and concurrency for full-document translation.',
                    )}
                  >
                    <div className="grid gap-3 md:grid-cols-2">
                      <div className="space-y-2">
                        <div className="text-xs font-medium text-slate-500">
                          {l('每批块数', 'Blocks Per Batch')}
                        </div>
                        <SettingsInput
                          type="number"
                          min={1}
                          max={50}
                          value={String(settings.translationBatchSize)}
                          onChange={(event) =>
                            onSettingChange(
                              'translationBatchSize',
                              Math.max(1, Math.min(50, Number(event.target.value) || 1)),
                            )
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <div className="text-xs font-medium text-slate-500">
                          {l('并发数', 'Concurrency')}
                        </div>
                        <SettingsInput
                          type="number"
                          min={1}
                          max={8}
                          value={String(settings.translationConcurrency)}
                          onChange={(event) =>
                            onSettingChange(
                              'translationConcurrency',
                              Math.max(1, Math.min(8, Number(event.target.value) || 1)),
                            )
                          }
                        />
                      </div>
                    </div>
                  </SettingsField>

                  {false ? (
                  <SettingsField
                    label="Model Status and Test"
                    description="Saved models are shared across document translation, selection translation, summary, and QA. This test uses the current document translation model."
                  >
                    <div className="grid gap-3 md:grid-cols-3">
                      {[
                        { label: 'Document', preset: activeTranslationPreset },
                        {
                          label: 'Selection',
                          preset: activeSelectionTranslationPreset ?? activeTranslationPreset,
                        },
                        {
                          label: 'Summary / Preview',
                          preset: activeSummaryPreset ?? activeTranslationPreset,
                        },
                      ].map((item) => (
                        <div
                          key={item.label}
                          className="rounded-2xl border border-slate-200 bg-slate-50/80 p-3"
                        >
                          <div className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">
                            {item.label}
                          </div>
                          <div className="mt-2 text-sm font-medium text-slate-900">
                            {item.preset?.label || item.preset?.model || 'Unselected'}
                          </div>
                          <div className="mt-1 truncate text-xs text-slate-500">
                            {item.preset?.model || 'No model configured'}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <div className="text-sm font-medium text-slate-900">Test Current Translation Model</div>
                          <div className="mt-1 text-xs leading-5 text-slate-500">
                            Send a minimal `chat/completions` request with the model bound to document translation.
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => void handleTestLlmConnection()}
                          disabled={!canTestLlm || llmTestLoading}
                          className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800 disabled:opacity-55"
                        >
                          {llmTestLoading ? 'Testing...' : 'Test Connection'}
                        </button>
                      </div>

                      {!canTestLlm ? (
                        <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs leading-5 text-amber-700">
                          Bind a saved model with Base URL, API key, and model name before testing.
                        </div>
                      ) : null}

                      {llmTestResult ? (
                        <div
                          className={clsx(
                            'mt-3 rounded-xl border px-3 py-2 text-xs leading-5',
                            llmTestResult!.ok
                              ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                              : 'border-rose-200 bg-rose-50 text-rose-700',
                          )}
                        >
                          <div className="font-medium">
                            {llmTestResult!.ok ? 'Connected' : 'Failed'}
                            {llmTestResult!.latencyMs ? ` 鐠?${llmTestResult!.latencyMs} ms` : ''}
                          </div>
                          <div className="mt-1 break-all">
                            Endpoint: {llmTestResult!.endpoint || 'Unresolved'}
                          </div>
                          <div className="mt-1 break-all">
                            Model: {llmTestResult!.responseModel || llmTestResult!.model || 'No response model'}
                          </div>
                          <div className="mt-1 whitespace-pre-wrap">{llmTestResult!.message}</div>
                        </div>
                      ) : null}
                    </div>
                  </SettingsField>
                  ) : null}





                  <SettingsField
                    label={l('摘要输入来源', 'Summary Input Source')}
                    description={l(
                      '决定摘要优先读取 PDF 文本还是 MinerU Markdown。',
                      'Decide whether summary generation should prefer PDF text or MinerU Markdown.',
                    )}
                  >
                    <div className="rounded-2xl border border-slate-200 bg-slate-50/80 p-3">
                      <div className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">
                        {l('当前摘要模型', 'Current Summary Preset')}
                      </div>
                      <div className="mt-2 text-sm font-medium text-slate-900">
                        {activeSummaryPreset?.label ||
                          activeSummaryPreset?.model ||
                          l('未选择', 'Unselected')}
                      </div>
                      <div className="mt-1 truncate text-xs text-slate-500">
                        {activeSummaryPreset?.baseUrl || l('未配置 Base URL', 'Base URL not configured')}
                      </div>
                    </div>

                    <div>
                      <div className="mb-2 text-xs font-medium text-slate-500">
                        {l('摘要输入模式', 'Summary Source Mode')}
                      </div>
                      <div className="grid gap-2">
                        {summarySourceOptions.map((option) => (
                          <button
                            key={option.value}
                            type="button"
                            onClick={() => onSettingChange('summarySourceMode', option.value)}
                            className={clsx(
                              'rounded-2xl border px-4 py-3 text-left transition',
                              settings.summarySourceMode === option.value
                                ? 'border-indigo-200 bg-indigo-50/70'
                                : 'border-slate-200 bg-slate-50/70 hover:bg-slate-100',
                            )}
                          >
                            <div className="text-sm font-medium text-slate-900">{option.label}</div>
                            <div className="mt-1 text-xs leading-5 text-slate-500">
                              {option.description}
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </SettingsField>

                  <SettingsField
                    label={l('翻译体验', 'Translation Experience')}
                    description={l(
                      '配置语言方向、自动划词翻译和文档级翻译操作。',
                      'Configure language direction, auto selection translation, and document-level translation actions.',
                    )}
                  >
                    <div className="grid gap-3 md:grid-cols-2">
                      <div className="space-y-2">
                        <div className="text-xs font-medium text-slate-500">
                          {l('源语言', 'Source Language')}
                        </div>
                        <SettingsSelect
                          value={settings.translationSourceLanguage}
                          onChange={(event) =>
                            onSettingChange('translationSourceLanguage', event.target.value)
                          }
                        >
                          {languageOptions.map((language) => (
                            <option key={language.value} value={language.value}>
                              {language.label}
                            </option>
                          ))}
                        </SettingsSelect>
                      </div>
                      <div className="space-y-2">
                        <div className="text-xs font-medium text-slate-500">
                          {l('目标语言', 'Target Language')}
                        </div>
                        <SettingsSelect
                          value={settings.translationTargetLanguage}
                          onChange={(event) =>
                            onSettingChange('translationTargetLanguage', event.target.value)
                          }
                        >
                          {languageOptions
                            .filter((language) => language.value !== 'auto')
                            .map((language) => (
                              <option key={language.value} value={language.value}>
                                {language.label}
                              </option>
                            ))}
                        </SettingsSelect>
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-200 bg-slate-50/70 px-3 py-2 text-xs leading-5 text-slate-500">
                      {l(
                        '整篇翻译会按结构块分批调用模型，并将结果缓存到当前文档会话中。',
                        'Full-document translation is executed in batches by structured blocks and cached in the current document session.',
                      )}
                    </div>

                    <ToggleRow
                      title={l('自动翻译划词', 'Auto Translate Selection')}
                      description={l(
                        '选中文本后自动请求翻译，无需手动点击翻译按钮。',
                        'Automatically translate selected text without requiring a manual click.',
                      )}
                      checked={settings.autoTranslateSelection}
                      onChange={(checked) => onSettingChange('autoTranslateSelection', checked)}
                    />

                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => onTranslate?.()}
                        disabled={!canTriggerTranslate || translating}
                        className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800 disabled:opacity-60"
                      >
                        <Languages className="mr-2 inline h-4 w-4" strokeWidth={1.8} />
                        {translating
                          ? l('翻译中...', 'Translating...')
                          : l('开始整篇翻译', 'Translate Document')}
                      </button>
                      <button
                        type="button"
                        onClick={() => onClearTranslations?.()}
                        disabled={!canClearTranslations}
                        className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 text-sm text-slate-700 transition hover:bg-slate-100 disabled:opacity-60"
                      >
                        {l('清空翻译缓存', 'Clear Translation Cache')}
                      </button>
                    </div>
                  </SettingsField>
                </>
              ) : null}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

function Reader() {
  const appWindow = getCurrentWindow();
  const librarySearchInputRef = useRef<HTMLInputElement>(null);
  const libraryItemClickTimerRef = useRef<number | null>(null);
  const libraryPreviewRequestIdRef = useRef<Record<string, number>>({});
  const legacyModelPresetMigrationDoneRef = useRef(false);
  const autoMineruAttemptedRef = useRef<Set<string>>(new Set());
  const autoSummaryAttemptedRef = useRef<Set<string>>(new Set());
  const batchMineruRunningRef = useRef(false);
  const batchSummaryRunningRef = useRef(false);
  const batchMineruPausedRef = useRef(false);
  const batchSummaryPausedRef = useRef(false);
  const batchMineruCancelRequestedRef = useRef(false);
  const batchSummaryCancelRequestedRef = useRef(false);

  const tabs = useTabsStore((state) => state.tabs);
  const activeTabId = useTabsStore((state) => state.activeTabId);
  const openTab = useTabsStore((state) => state.openTab);
  const closeTab = useTabsStore((state) => state.closeTab);
  const setActiveTab = useTabsStore((state) => state.setActiveTab);
  const setHomeTabTitle = useTabsStore((state) => state.setHomeTabTitle);

  const [settings, setSettings] = useState<ReaderSettings>(loadSettings);
  const [readerSecrets, setReaderSecrets] = useState<ReaderSecrets>(loadSecrets);
  const [preferencesOpen, setPreferencesOpen] = useState(false);
  const [zoteroLocalDataDir, setZoteroLocalDataDir] = useState('');
  const [leftSidebarCollapsed, setLeftSidebarCollapsed] = useState(() =>
    loadStoredBoolean(LEFT_SIDEBAR_COLLAPSED_STORAGE_KEY),
  );
  const [appDefaultPaths, setAppDefaultPaths] = useState<AppDefaultPaths | null>(null);
  const [configHydrated, setConfigHydrated] = useState(false);

  const [zoteroCollections, setZoteroCollections] = useState<ZoteroCollection[]>([]);
  const [zoteroAllItems, setZoteroAllItems] = useState<WorkspaceItem[]>([]);
  const [collectionItemsCache, setCollectionItemsCache] = useState<Record<string, WorkspaceItem[]>>(
    {},
  );
  const [standaloneItems, setStandaloneItems] = useState<WorkspaceItem[]>([]);
  const [selectedSectionKey, setSelectedSectionKey] = useState<LibrarySectionKey>('recent');
  const [selectedLibraryItemId, setSelectedLibraryItemId] = useState<string | null>(null);
  const [librarySearchQuery, setLibrarySearchQuery] = useState('');
  const [libraryDisplayMode, setLibraryDisplayMode] = useState<'list' | 'card'>('list');
  const [libraryLoading, setLibraryLoading] = useState(false);
  const [libraryLoadingSection, setLibraryLoadingSection] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState('');
  const [error, setError] = useState('');
  const [readerBridges, setReaderBridges] = useState<Record<string, ReaderTabBridgeState>>({});
  const [libraryPreviewStates, setLibraryPreviewStates] = useState<
    Record<string, LibraryPreviewState>
  >({});
  const [itemParseStatusMap, setItemParseStatusMap] = useState<Record<string, boolean | undefined>>(
    {},
  );
  const [pendingCloudParseTabId, setPendingCloudParseTabId] = useState<string | null>(null);
  const [pendingTranslateTabId, setPendingTranslateTabId] = useState<string | null>(null);
  const [batchMineruRunning, setBatchMineruRunning] = useState(false);
  const [batchSummaryRunning, setBatchSummaryRunning] = useState(false);
  const [batchMineruPaused, setBatchMineruPaused] = useState(false);
  const [batchSummaryPaused, setBatchSummaryPaused] = useState(false);
  const [batchMineruProgress, setBatchMineruProgress] = useState<BatchProgressState>(
    EMPTY_BATCH_PROGRESS,
  );
  const [batchSummaryProgress, setBatchSummaryProgress] = useState<BatchProgressState>(
    EMPTY_BATCH_PROGRESS,
  );
  const {
    mineruApiToken,
    translationApiKey,
    summaryApiKey,
    zoteroApiKey,
    zoteroUserId,
    qaModelPresets,
  } = readerSecrets;
  const l = useCallback(
    <T,>(zh: T, en: T) => pickLocaleText(settings.uiLanguage, zh, en),
    [settings.uiLanguage],
  );
  useEffect(() => {
    setHomeTabTitle(getHomeTabTitle(settings.uiLanguage));
  }, [setHomeTabTitle, settings.uiLanguage]);
  const notLoadedText = l('未加载', 'Not Loaded');
  const noPdfLoadedText = l('未加载 PDF', 'No PDF Loaded');
  const noJsonLoadedText = l('未加载 JSON', 'No JSON Loaded');
  const noSelectionText = l('未选择', 'Unselected');
  const translationModelPreset = useMemo(
    () => resolveModelPreset(qaModelPresets, settings.translationModelPresetId),
    [qaModelPresets, settings.translationModelPresetId],
  );
  const selectionTranslationModelPreset = useMemo(
    () =>
      resolveModelPreset(qaModelPresets, settings.selectionTranslationModelPresetId) ??
      translationModelPreset,
    [qaModelPresets, settings.selectionTranslationModelPresetId, translationModelPreset],
  );
  const summaryModelPreset = useMemo(
    () => resolveModelPreset(qaModelPresets, settings.summaryModelPresetId) ?? translationModelPreset,
    [qaModelPresets, settings.summaryModelPresetId, translationModelPreset],
  );
  const summaryConfigured = Boolean(
    summaryModelPreset?.apiKey.trim() &&
      summaryModelPreset?.baseUrl.trim() &&
      summaryModelPreset?.model.trim(),
  );

  useEffect(() => {
    let cancelled = false;

    void (async () => {
      try {
        const defaultPaths = await getAppDefaultPaths();

        if (cancelled) {
          return;
        }

        setAppDefaultPaths(defaultPaths);
        let nextConfig = mergeReaderConfigWithDefaults(
          null,
          loadSettings(),
          loadSecrets(),
          defaultPaths,
        );

        try {
          const configText = await readLocalTextFile(defaultPaths.configPath);
          const parsedConfig = JSON.parse(configText) as Partial<ReaderConfigFile>;

          nextConfig = mergeReaderConfigWithDefaults(
            parsedConfig,
            loadSettings(),
            loadSecrets(),
            defaultPaths,
          );
        } catch {
          try {
            const legacyConfigText = await readLocalTextFile(
              buildLegacyConfigPath(defaultPaths.executableDir),
            );
            const parsedLegacyConfig = JSON.parse(legacyConfigText) as Partial<ReaderConfigFile>;

            nextConfig = mergeReaderConfigWithDefaults(
              parsedLegacyConfig,
              loadSettings(),
              loadSecrets(),
              defaultPaths,
            );
          } catch {
          }
        }
        if (cancelled) {
          return;
        }

        setSettings(nextConfig.settings);
        setReaderSecrets(nextConfig.secrets);
        setZoteroLocalDataDir(nextConfig.zoteroLocalDataDir);
        setLeftSidebarCollapsed(nextConfig.leftSidebarCollapsed);
      } finally {
        if (!cancelled) {
          setConfigHydrated(true);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  const handleOpenPreferences = useCallback(() => {
    setPreferencesOpen(true);
  }, []);

  useEffect(() => {
    if (legacyModelPresetMigrationDoneRef.current) {
      return;
    }

    legacyModelPresetMigrationDoneRef.current = true;

    const nextPresets = buildLegacyModelPresets(settings, readerSecrets);
    const hasPresetMismatch =
      nextPresets.length !== qaModelPresets.length ||
      nextPresets.some((preset, index) => qaModelPresets[index]?.id !== preset.id);
    const fallbackPresetId = nextPresets[0]?.id ?? DEFAULT_QA_PRESET_ID;
    const nextTranslationPresetId =
      resolveModelPreset(nextPresets, settings.translationModelPresetId)?.id ?? fallbackPresetId;
    const nextSelectionTranslationPresetId =
      resolveModelPreset(nextPresets, settings.selectionTranslationModelPresetId)?.id ??
      nextTranslationPresetId;
    const nextSummaryPresetId =
      resolveModelPreset(nextPresets, settings.summaryModelPresetId)?.id ?? fallbackPresetId;
    const nextQaPresetId =
      resolveModelPreset(nextPresets, settings.qaActivePresetId)?.id ?? fallbackPresetId;
    const nextTranslationPreset =
      resolveModelPreset(nextPresets, nextTranslationPresetId) ?? DEFAULT_QA_PRESET;
    const nextSummaryPreset =
      resolveModelPreset(nextPresets, nextSummaryPresetId) ?? DEFAULT_QA_PRESET;

    if (hasPresetMismatch) {
      setReaderSecrets((current) => ({
        ...current,
        qaModelPresets: nextPresets,
        translationApiKey: nextTranslationPreset.apiKey,
        summaryApiKey: nextSummaryPreset.apiKey,
      }));
    } else if (
      readerSecrets.translationApiKey !== nextTranslationPreset.apiKey ||
      readerSecrets.summaryApiKey !== nextSummaryPreset.apiKey
    ) {
      setReaderSecrets((current) => ({
        ...current,
        translationApiKey: nextTranslationPreset.apiKey,
        summaryApiKey: nextSummaryPreset.apiKey,
      }));
    }

    if (
      settings.translationModelPresetId !== nextTranslationPresetId ||
      settings.selectionTranslationModelPresetId !== nextSelectionTranslationPresetId ||
      settings.summaryModelPresetId !== nextSummaryPresetId ||
      settings.qaActivePresetId !== nextQaPresetId ||
      settings.translationBaseUrl !== nextTranslationPreset.baseUrl ||
      settings.translationModel !== nextTranslationPreset.model ||
      settings.summaryBaseUrl !== nextSummaryPreset.baseUrl ||
      settings.summaryModel !== nextSummaryPreset.model
    ) {
      setSettings((current) => ({
        ...current,
        translationModelPresetId: nextTranslationPresetId,
        selectionTranslationModelPresetId: nextSelectionTranslationPresetId,
        summaryModelPresetId: nextSummaryPresetId,
        qaActivePresetId: nextQaPresetId,
        translationBaseUrl: nextTranslationPreset.baseUrl,
        translationModel: nextTranslationPreset.model,
        summaryBaseUrl: nextSummaryPreset.baseUrl,
        summaryModel: nextSummaryPreset.model,
      }));
    }
  }, [
    qaModelPresets,
    readerSecrets,
    settings,
  ]);

  useEffect(() => {
    const fallbackPresetId = qaModelPresets[0]?.id ?? DEFAULT_QA_PRESET_ID;
    const nextTranslationPresetId =
      resolveModelPreset(qaModelPresets, settings.translationModelPresetId)?.id ?? fallbackPresetId;
    const nextSelectionTranslationPresetId =
      resolveModelPreset(qaModelPresets, settings.selectionTranslationModelPresetId)?.id ??
      nextTranslationPresetId;
    const nextSummaryPresetId =
      resolveModelPreset(qaModelPresets, settings.summaryModelPresetId)?.id ?? fallbackPresetId;
    const nextQaPresetId =
      resolveModelPreset(qaModelPresets, settings.qaActivePresetId)?.id ?? fallbackPresetId;
    const nextTranslationPreset =
      resolveModelPreset(qaModelPresets, nextTranslationPresetId) ?? DEFAULT_QA_PRESET;
    const nextSummaryPreset =
      resolveModelPreset(qaModelPresets, nextSummaryPresetId) ?? DEFAULT_QA_PRESET;

    if (
      settings.translationModelPresetId !== nextTranslationPresetId ||
      settings.selectionTranslationModelPresetId !== nextSelectionTranslationPresetId ||
      settings.summaryModelPresetId !== nextSummaryPresetId ||
      settings.qaActivePresetId !== nextQaPresetId ||
      settings.translationBaseUrl !== nextTranslationPreset.baseUrl ||
      settings.translationModel !== nextTranslationPreset.model ||
      settings.summaryBaseUrl !== nextSummaryPreset.baseUrl ||
      settings.summaryModel !== nextSummaryPreset.model
    ) {
      setSettings((current) => ({
        ...current,
        translationModelPresetId: nextTranslationPresetId,
        selectionTranslationModelPresetId: nextSelectionTranslationPresetId,
        summaryModelPresetId: nextSummaryPresetId,
        qaActivePresetId: nextQaPresetId,
        translationBaseUrl: nextTranslationPreset.baseUrl,
        translationModel: nextTranslationPreset.model,
        summaryBaseUrl: nextSummaryPreset.baseUrl,
        summaryModel: nextSummaryPreset.model,
      }));
    }

    if (
      readerSecrets.translationApiKey !== nextTranslationPreset.apiKey ||
      readerSecrets.summaryApiKey !== nextSummaryPreset.apiKey
    ) {
      setReaderSecrets((current) => ({
        ...current,
        translationApiKey: nextTranslationPreset.apiKey,
        summaryApiKey: nextSummaryPreset.apiKey,
      }));
    }
  }, [
    qaModelPresets,
    readerSecrets.summaryApiKey,
    readerSecrets.translationApiKey,
    settings.qaActivePresetId,
    settings.selectionTranslationModelPresetId,
    settings.summaryBaseUrl,
    settings.summaryModel,
    settings.summaryModelPresetId,
    settings.translationBaseUrl,
    settings.translationModel,
    settings.translationModelPresetId,
  ]);

  const activeTab = useMemo(
    () => tabs.find((tab) => tab.id === activeTabId) ?? tabs[0],
    [activeTabId, tabs],
  );

  const flattenedCollections = useMemo(
    () => buildFlatCollections(zoteroCollections),
    [zoteroCollections],
  );

  const collectionNameMap = useMemo(
    () => new Map(flattenedCollections.map((collection) => [collection.collectionKey, collection.name])),
    [flattenedCollections],
  );

  const selectedSectionTitle = useMemo(() => {
    if (selectedSectionKey === 'recent') {
      return l('最近', 'Recent');
    }

    if (selectedSectionKey === 'all') {
      return l('全部 PDF', 'All PDFs');
    }

    if (selectedSectionKey === 'standalone') {
      return l('独立 PDF', 'Standalone PDFs');
    }

    const collectionKey = selectedSectionKey.slice('collection:'.length);

    return collectionNameMap.get(collectionKey) ?? l('未命名分类', 'Untitled Collection');
  }, [collectionNameMap, l, selectedSectionKey]);

  const currentSectionItems = useMemo(() => {
    if (selectedSectionKey === 'recent') {
      return zoteroAllItems.slice(0, 30);
    }

    if (selectedSectionKey === 'all') {
      return zoteroAllItems;
    }

    if (selectedSectionKey === 'standalone') {
      return standaloneItems;
    }

    const collectionKey = selectedSectionKey.slice('collection:'.length);

    return collectionItemsCache[collectionKey] ?? [];
  }, [collectionItemsCache, selectedSectionKey, standaloneItems, zoteroAllItems]);

  const visibleItems = useMemo(
    () => currentSectionItems.filter((item) => matchesLibraryQuery(item, librarySearchQuery)),
    [currentSectionItems, librarySearchQuery],
  );

  const workspaceItemMap = useMemo(() => {
    const itemMap = new Map<string, WorkspaceItem>();

    const applyItems = (items: WorkspaceItem[]) => {
      for (const item of items) {
        const existingItem = itemMap.get(item.workspaceId);

        if (!existingItem) {
          itemMap.set(item.workspaceId, item);
          continue;
        }

        itemMap.set(item.workspaceId, {
          ...existingItem,
          ...item,
          localPdfPath: mergeLocalPdfPath(existingItem, item),
        });
      }
    };

    applyItems(zoteroAllItems);
    applyItems(standaloneItems);
    Object.values(collectionItemsCache).forEach(applyItems);

    return itemMap;
  }, [collectionItemsCache, standaloneItems, zoteroAllItems]);

  const allKnownItems = useMemo(
    () => Array.from(workspaceItemMap.values()),
    [workspaceItemMap],
  );

  const readerTabs = useMemo(
    () => tabs.filter((tab): tab is ReaderTab => tab.type === 'reader'),
    [tabs],
  );

  const selectedLibraryItem = useMemo(() => {
    if (!selectedLibraryItemId) {
      return null;
    }

    return workspaceItemMap.get(selectedLibraryItemId) ?? null;
  }, [selectedLibraryItemId, workspaceItemMap]);

  const activeReaderBridge =
    activeTab?.type === 'reader' ? readerBridges[activeTab.id] ?? null : null;

  const selectedItemId =
    activeTab?.type === 'reader' ? activeTab.documentId : selectedLibraryItemId;

  const activeLibraryPreviewState = selectedLibraryItem
    ? libraryPreviewStates[selectedLibraryItem.workspaceId] ?? EMPTY_LIBRARY_PREVIEW_STATE
    : EMPTY_LIBRARY_PREVIEW_STATE;

  const mapZoteroItems = (items: ZoteroLibraryItem[]): WorkspaceItem[] =>
    items.map((item) => normalizeWorkspaceItem(item, 'zotero-local'));

  const handleWorkspaceItemResolved = useCallback((resolvedItem: WorkspaceItem) => {
    const mergeItem = (item: WorkspaceItem) =>
      item.workspaceId === resolvedItem.workspaceId
        ? {
            ...item,
            ...resolvedItem,
            localPdfPath: mergeLocalPdfPath(item, resolvedItem),
          }
        : item;

    setZoteroAllItems((current) => current.map(mergeItem));
    setStandaloneItems((current) => current.map(mergeItem));
    setCollectionItemsCache((current) =>
      Object.fromEntries(
        Object.entries(current).map(([collectionKey, items]) => [
          collectionKey,
          items.map(mergeItem),
        ]),
      ),
    );
    setLibraryPreviewStates((current) => {
      const existingState = current[resolvedItem.workspaceId];

      if (!existingState || !resolvedItem.localPdfPath) {
        return current;
      }

      const nextPdfName = getFileNameFromPath(resolvedItem.localPdfPath);

      if (existingState.currentPdfName === nextPdfName) {
        return current;
      }

      return {
        ...current,
        [resolvedItem.workspaceId]: {
          ...existingState,
          currentPdfName: nextPdfName,
        },
      };
    });
  }, []);

  const handleLibraryPreviewSync = useCallback((payload: LibraryPreviewSyncPayload) => {
    setItemParseStatusMap((current) => ({
      ...current,
      [payload.item.workspaceId]: payload.hasBlocks,
    }));

    setLibraryPreviewStates((current) => {
      const existingState = current[payload.item.workspaceId];
      const hasSummary = Object.prototype.hasOwnProperty.call(payload, 'summary');
      const hasLoading = Object.prototype.hasOwnProperty.call(payload, 'loading');
      const hasError = Object.prototype.hasOwnProperty.call(payload, 'error');

      return {
        ...current,
        [payload.item.workspaceId]: {
          summary: hasSummary ? payload.summary ?? null : existingState?.summary ?? null,
          loading: hasLoading ? Boolean(payload.loading) : false,
          error: hasError ? payload.error ?? '' : '',
          hasBlocks: payload.hasBlocks,
          blockCount: payload.blockCount,
          currentPdfName: payload.currentPdfName,
          currentJsonName: payload.currentJsonName,
          statusMessage: payload.statusMessage,
          sourceKey: payload.sourceKey,
        },
      };
    });
  }, []);

  const resolveMineruJsonCandidatePaths = useCallback((item: WorkspaceItem): string[] => {
    const candidates = new Set<string>();

    if (settings.mineruCacheDir.trim()) {
      for (const cachePaths of [
        buildMineruCachePaths(settings.mineruCacheDir.trim(), item),
        buildLegacyMineruCachePaths(settings.mineruCacheDir.trim(), item),
      ]) {
        candidates.add(cachePaths.contentJsonPath);
        candidates.add(cachePaths.middleJsonPath);
      }
    }

    if (item.localPdfPath && settings.autoLoadSiblingJson) {
      candidates.add(guessSiblingJsonPath(item.localPdfPath));
    }

    return Array.from(candidates);
  }, [settings.autoLoadSiblingJson, settings.mineruCacheDir]);

  const findExistingMineruJson = useCallback(
    async (item: WorkspaceItem) => {
      for (const candidatePath of resolveMineruJsonCandidatePaths(item)) {
        try {
          const jsonText = await readLocalTextFile(candidatePath);

          if (jsonText.trim()) {
            return {
              path: candidatePath,
              jsonText,
            };
          }
        } catch {
          continue;
        }
      }

      return null;
    },
    [resolveMineruJsonCandidatePaths],
  );

  useEffect(() => {
    if (allKnownItems.length === 0) {
      setItemParseStatusMap({});
      return;
    }

    let cancelled = false;

    void (async () => {
      const nextEntries = await Promise.all(
        allKnownItems.map(async (item) => [item.workspaceId, Boolean(await findExistingMineruJson(item))] as const),
      );

      if (cancelled) {
        return;
      }

      setItemParseStatusMap((current) => ({
        ...current,
        ...Object.fromEntries(nextEntries),
      }));
    })();

    return () => {
      cancelled = true;
    };
  }, [allKnownItems, findExistingMineruJson]);

  const saveLibraryMineruParseCache = useCallback(
    async ({
      item,
      pdfPath,
      sourceKind,
      contentJsonText,
      middleJsonText,
      markdownText,
      batchId,
      dataId,
      fileName,
      zipEntries,
    }: {
      item: WorkspaceItem;
      pdfPath: string;
      sourceKind: MineruCacheManifest['sourceKind'];
      contentJsonText?: string | null;
      middleJsonText?: string | null;
      markdownText?: string | null;
      batchId?: string;
      dataId?: string;
      fileName?: string;
      zipEntries?: string[];
    }) => {
      if (!settings.mineruCacheDir.trim()) {
        return null;
      }

      const cachePaths = buildMineruCachePaths(settings.mineruCacheDir.trim(), item);
      const writeTasks: Promise<void>[] = [];

      if (contentJsonText?.trim()) {
        writeTasks.push(writeLocalTextFile(cachePaths.contentJsonPath, contentJsonText));
      }

      if (middleJsonText?.trim()) {
        writeTasks.push(writeLocalTextFile(cachePaths.middleJsonPath, middleJsonText));
      }

      if (markdownText?.trim()) {
        writeTasks.push(writeLocalTextFile(cachePaths.markdownPath, markdownText));
      }

      const manifest: MineruCacheManifest = {
        version: 1,
        documentKey: item.itemKey,
        title: item.title,
        pdfPath,
        savedAt: new Date().toISOString(),
        sourceKind,
        batchId,
        dataId,
        fileName,
        zipEntries,
      };

      writeTasks.push(
        writeLocalTextFile(cachePaths.manifestPath, JSON.stringify(manifest, null, 2)),
      );

      await Promise.all(writeTasks);

      return cachePaths;
    },
    [settings.mineruCacheDir],
  );

  const syncLibraryParsedState = useCallback(
    (
      item: WorkspaceItem,
      jsonText: string,
      jsonPath: string,
      status: string,
    ) => {
      const pages = parseMineruPages(jsonText);
      const blocks = flattenMineruPages(pages);
      const currentJsonName = getFileNameFromPath(jsonPath);
      const currentPdfName = item.localPdfPath
        ? getFileNameFromPath(item.localPdfPath)
        : noPdfLoadedText;

      setItemParseStatusMap((current) => ({
        ...current,
        [item.workspaceId]: true,
      }));
      setLibraryPreviewStates((current) => {
        const previousState = current[item.workspaceId] ?? EMPTY_LIBRARY_PREVIEW_STATE;

        return {
          ...current,
          [item.workspaceId]: {
            ...previousState,
            loading: false,
            error: '',
            hasBlocks: blocks.length > 0,
            blockCount: blocks.length,
            currentPdfName,
            currentJsonName,
            statusMessage: status,
            sourceKey:
              previousState.sourceKey || `${item.workspaceId}::${currentJsonName}::${blocks.length}`,
          },
        };
      });

      return {
        pages,
        blocks,
      };
    },
    [noPdfLoadedText],
  );

  const loadLocalLibrary = async (preferredDataDir?: string, silent = false) => {
    setLibraryLoading(true);
    setError('');

    try {
      const resolvedDataDir =
        preferredDataDir?.trim() ||
        zoteroLocalDataDir.trim() ||
        (await detectLocalZoteroDataDir()) ||
        '';

        if (!resolvedDataDir) {
          setZoteroCollections([]);
          setZoteroAllItems([]);
          setCollectionItemsCache({});

          if (!silent) {
            setStatusMessage(l('未找到 Zotero 本地目录', 'No Zotero local directory found'));
          }

          return;
      }

      const [collections, items] = await Promise.all([
        listLocalZoteroCollections({ dataDir: resolvedDataDir }),
        listLocalZoteroLibraryItems({ dataDir: resolvedDataDir, limit: 400 }),
      ]);

      setZoteroLocalDataDir(resolvedDataDir);
      setZoteroCollections(collections);
      setZoteroAllItems(mapZoteroItems(items));
      setCollectionItemsCache({});
      setStatusMessage(
        l(
          `已加载 Zotero 本地文库，共发现 ${items.length} 篇 PDF 记录`,
          `Loaded the local Zotero library with ${items.length} PDF records`,
        ),
      );
    } catch (nextError) {
      if (!silent) {
        setError(
          nextError instanceof Error
            ? nextError.message
            : l('读取 Zotero 文库失败', 'Failed to load the Zotero library'),
        );
      }

      setStatusMessage(l('读取 Zotero 文库失败', 'Failed to load the Zotero library'));
    } finally {
      setLibraryLoading(false);
    }
  };

  const ensureCollectionItems = async (collectionKey: string) => {
    if (!zoteroLocalDataDir.trim() || collectionItemsCache[collectionKey]) {
      return;
    }

    setLibraryLoadingSection(collectionKey);

    try {
      const items = await listLocalZoteroCollectionItems({
        dataDir: zoteroLocalDataDir.trim(),
        collectionKey,
        limit: 400,
      });

      setCollectionItemsCache((current) => ({
        ...current,
        [collectionKey]: mapZoteroItems(items),
      }));
      setStatusMessage(
        l(
          `已加载分类：${collectionNameMap.get(collectionKey) ?? l('未命名分类', 'Untitled Collection')}`,
          `Loaded collection: ${
            collectionNameMap.get(collectionKey) ?? l('Untitled Collection', 'Untitled Collection')
          }`,
        ),
      );
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : l('读取分类文献失败', 'Failed to load collection items'),
      );
      setStatusMessage(l('读取分类文献失败', 'Failed to load collection items'));
    } finally {
      setLibraryLoadingSection((current) => (current === collectionKey ? null : current));
    }
  };

  const handleDetectLocalZotero = async () => {
    setLibraryLoading(true);
    setError('');

    try {
      const dataDir = await detectLocalZoteroDataDir();

      if (!dataDir) {
        setStatusMessage(l('未找到 Zotero 本地目录', 'No Zotero local directory found'));
        return;
      }

      await loadLocalLibrary(dataDir);
    } finally {
      setLibraryLoading(false);
    }
  };

  const handleSelectLocalZoteroDir = async () => {
    setError('');

    try {
      const dataDir = await selectLocalZoteroDataDir();

      if (!dataDir) {
        setStatusMessage(l('未选择 Zotero 目录', 'No Zotero directory selected'));
        return;
      }

      await loadLocalLibrary(dataDir);
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : l('选择 Zotero 目录失败', 'Failed to choose the Zotero directory'),
      );
      setStatusMessage(l('选择 Zotero 目录失败', 'Failed to choose the Zotero directory'));
    }
  };

  const handleReloadLocalZotero = async () => {
    await loadLocalLibrary();
  };

  const handleSelectLibrarySection = async (sectionKey: LibrarySectionKey) => {
    setSelectedSectionKey(sectionKey);
    setLibrarySearchQuery('');

    if (sectionKey.startsWith('collection:')) {
      const collectionKey = sectionKey.slice('collection:'.length);
      await ensureCollectionItems(collectionKey);
    }
  };

  const loadLibraryPreviewBlocks = async (
    item: WorkspaceItem,
  ): Promise<LibraryPreviewLoadResult> => {
    const pdfName = item.localPdfPath ? getFileNameFromPath(item.localPdfPath) : noPdfLoadedText;

    if (settings.mineruCacheDir.trim()) {
      const cachePaths = buildMineruCachePaths(settings.mineruCacheDir.trim(), item);

      for (const candidatePath of [cachePaths.contentJsonPath, cachePaths.middleJsonPath]) {
        try {
          const jsonText = await readLocalTextFile(candidatePath);
          const pages = parseMineruPages(jsonText);
          const blocks = flattenMineruPages(pages);

          return {
            blocks,
            currentPdfName: pdfName,
            currentJsonName: getFileNameFromPath(candidatePath),
            statusMessage: l(
              `已从缓存加载 ${blocks.length} 个结构块`,
              `Loaded ${blocks.length} structured blocks from cache`,
            ),
          };
        } catch {
          continue;
        }
      }
    }

    if (item.localPdfPath && settings.autoLoadSiblingJson) {
      const siblingJsonPath = guessSiblingJsonPath(item.localPdfPath);

      try {
        const jsonText = await readLocalTextFile(siblingJsonPath);
        const pages = parseMineruPages(jsonText);
        const blocks = flattenMineruPages(pages);

        return {
          blocks,
          currentPdfName: pdfName,
          currentJsonName: getFileNameFromPath(siblingJsonPath),
          statusMessage: l(
            `已从同目录 JSON 加载 ${blocks.length} 个结构块`,
            `Loaded ${blocks.length} structured blocks from the sibling JSON`,
          ),
        };
      } catch {
        return {
          blocks: [],
          currentPdfName: pdfName,
          currentJsonName: noJsonLoadedText,
          statusMessage: l(
            '未找到同目录 JSON，请手动选择 MinerU JSON。',
            'No sibling JSON was found. Please choose a MinerU JSON file manually.',
          ),
        };
      }
    }

    return {
      blocks: [],
      currentPdfName: pdfName,
      currentJsonName: settings.autoLoadSiblingJson ? notLoadedText : noJsonLoadedText,
      statusMessage: item.localPdfPath
        ? l(
            '尚未检测到结构化结果，请手动选择 JSON 或执行 MinerU 解析。',
            'No structured result detected yet. Choose a JSON file or run MinerU parsing.',
          )
        : l(
            '当前文献没有可用 PDF，因此暂时无法匹配对应的 JSON。',
            'This document has no available PDF, so a matching JSON cannot be resolved yet.',
          ),
    };
  };

  const buildLibraryPreviewSummaryInputs = (blocks: PositionedMineruBlock[]) =>
    buildSummaryBlockInputs(blocks);

  const resolveLibraryPreviewSummaryRequest = async (
    item: WorkspaceItem,
    blocks: PositionedMineruBlock[],
  ) => {
    const summaryInputs = buildLibraryPreviewSummaryInputs(blocks);

    if (settings.summarySourceMode === 'pdf-text') {
      const pdfPath = item.localPdfPath?.trim() ?? '';
      const sourceKey = `${item.workspaceId}::${SUMMARY_PROMPT_VERSION}::pdf-text::${pdfPath || 'no-pdf'}`;

      if (!pdfPath) {
        return {
          summaryInputs,
          sourceKey,
          documentText: '',
          errorMessage: l(
            '摘要模式要求读取 PDF 文本，但当前文献没有可用 PDF。',
            'Summary mode requires PDF text, but no PDF is available for the current document.',
          ),
        };
      }

      const pdfData = await readLocalBinaryFile(pdfPath);
      const documentText = await extractPdfTextByPdfJs(pdfData);

      if (!documentText.trim()) {
        return {
          summaryInputs,
          sourceKey: `${sourceKey}::${pdfData.byteLength}`,
          documentText: '',
          errorMessage: l(
            '未能从 PDF 中提取可用文本。',
            'Failed to extract usable text from the PDF.',
          ),
        };
      }

      return {
        summaryInputs,
        sourceKey: `${sourceKey}::${pdfData.byteLength}`,
        documentText,
        errorMessage: '',
      };
    }

    const candidateMarkdownPaths = new Set<string>();

    if (settings.mineruCacheDir.trim()) {
      for (const cachePaths of [
        buildMineruCachePaths(settings.mineruCacheDir.trim(), item),
        buildLegacyMineruCachePaths(settings.mineruCacheDir.trim(), item),
      ]) {
        candidateMarkdownPaths.add(cachePaths.markdownPath);
      }
    }

    if (item.localPdfPath && settings.autoLoadSiblingJson) {
      candidateMarkdownPaths.add(guessSiblingMarkdownPath(item.localPdfPath));
    }

    for (const candidatePath of candidateMarkdownPaths) {
      try {
        const documentText = await readLocalTextFile(candidatePath);

        if (documentText.trim()) {
          return {
            summaryInputs,
            sourceKey: `${item.workspaceId}::${SUMMARY_PROMPT_VERSION}::mineru-markdown::${candidatePath}::${blocks.length}`,
            documentText,
            errorMessage: '',
          };
        }
      } catch {
        continue;
      }
    }

    const documentText = buildMineruMarkdownDocument(blocks);

    if (!documentText.trim()) {
      return {
        summaryInputs,
        sourceKey: `${item.workspaceId}::${SUMMARY_PROMPT_VERSION}::mineru-markdown::empty`,
        documentText: '',
        errorMessage: l(
          '未能生成可用的 MinerU Markdown 内容。',
          'Failed to generate usable MinerU Markdown content.',
        ),
      };
    }

    return {
      summaryInputs,
      sourceKey: `${item.workspaceId}::${SUMMARY_PROMPT_VERSION}::mineru-markdown::blocks::${blocks.length}`,
      documentText,
      errorMessage: '',
    };
  };

  const tryLoadSavedPreviewSummary = async (item: WorkspaceItem, sourceKey: string) => {
    if (!settings.mineruCacheDir.trim() || !sourceKey.trim()) {
      return null;
    }

    const candidatePaths = [
      buildMineruSummaryCachePath(settings.mineruCacheDir.trim(), item, sourceKey),
      buildLegacyMineruSummaryCachePath(settings.mineruCacheDir.trim(), item, sourceKey),
    ];

    for (const candidatePath of candidatePaths) {
      try {
        const raw = await readLocalTextFile(candidatePath);
        const parsed = JSON.parse(raw) as Partial<SummaryCacheEnvelope>;

        if (
          !parsed ||
          typeof parsed !== 'object' ||
          parsed.sourceKey !== sourceKey ||
          !parsed.summary
        ) {
          continue;
        }

        return parsed.summary as PaperSummary;
      } catch {
        continue;
      }
    }

    return null;
  };

  const savePreviewSummary = async (
    item: WorkspaceItem,
    sourceKey: string,
    summary: PaperSummary,
  ) => {
    if (!settings.mineruCacheDir.trim() || !sourceKey.trim()) {
      return;
    }

    const cachePath = buildMineruSummaryCachePath(settings.mineruCacheDir.trim(), item, sourceKey);
    const payload: SummaryCacheEnvelope = {
      version: 1,
      sourceKey,
      summarizedAt: new Date().toISOString(),
      summary,
    };

    await writeLocalTextFile(cachePath, JSON.stringify(payload, null, 2));
  };

  const generateLibraryPreview = async (
    item: WorkspaceItem,
    force = false,
    options?: {
      allowGenerate?: boolean;
    },
  ): Promise<LibraryPreviewOutcome> => {
    const allowGenerate = options?.allowGenerate ?? true;
    const cachedState = libraryPreviewStates[item.workspaceId];

    if (!force && cachedState) {
      if (cachedState.loading || cachedState.summary) {
        return 'loaded';
      }

      if (cachedState.hasBlocks && !allowGenerate) {
        setLibraryPreviewStates((current) => ({
          ...current,
          [item.workspaceId]: {
            ...cachedState,
            loading: false,
            error: '',
            statusMessage:
              cachedState.statusMessage ||
              l(
                '结构化内容已就绪，可以手动生成摘要。',
                'Structured content is ready. You can generate the summary manually.',
              ),
          },
        }));
        return 'loaded';
      }
    }

    const requestId = (libraryPreviewRequestIdRef.current[item.workspaceId] ?? 0) + 1;
    libraryPreviewRequestIdRef.current[item.workspaceId] = requestId;

    setLibraryPreviewStates((current) => ({
      ...current,
      [item.workspaceId]: {
        summary: force ? null : current[item.workspaceId]?.summary ?? null,
        loading: true,
        error: '',
        hasBlocks: current[item.workspaceId]?.hasBlocks ?? false,
        blockCount: current[item.workspaceId]?.blockCount ?? 0,
        currentPdfName: item.localPdfPath ? getFileNameFromPath(item.localPdfPath) : noPdfLoadedText,
        currentJsonName: current[item.workspaceId]?.currentJsonName ?? notLoadedText,
        statusMessage: l(
          '正在整理预览内容并生成 AI 摘要...',
          'Preparing the preview and generating the AI summary...',
        ),
        sourceKey: current[item.workspaceId]?.sourceKey ?? '',
      },
    }));

    try {
      const previewContext = await loadLibraryPreviewBlocks(item);
      const summaryRequest = await resolveLibraryPreviewSummaryRequest(item, previewContext.blocks);
      const {
        summaryInputs,
        sourceKey,
        documentText,
        errorMessage,
      } = summaryRequest;
      const historySummary =
        loadPaperHistory(item.workspaceId)?.paperSummarySourceKey === sourceKey
          ? loadPaperHistory(item.workspaceId)?.paperSummary ?? null
          : null;
      const cachedSummary = force ? null : await tryLoadSavedPreviewSummary(item, sourceKey);

      if (libraryPreviewRequestIdRef.current[item.workspaceId] !== requestId) {
        return 'skipped';
      }

      if (errorMessage && !documentText.trim() && summaryInputs.length === 0) {
        setLibraryPreviewStates((current) => ({
          ...current,
          [item.workspaceId]: {
            summary: null,
            loading: false,
            error: '',
            hasBlocks: false,
            blockCount: 0,
            currentPdfName: previewContext.currentPdfName,
            currentJsonName: previewContext.currentJsonName,
            statusMessage: errorMessage,
            sourceKey,
          },
        }));
        return 'skipped';
      }

      if (!force && historySummary) {
        setLibraryPreviewStates((current) => ({
          ...current,
          [item.workspaceId]: {
            summary: historySummary,
            loading: false,
            error: '',
            hasBlocks: Boolean(documentText.trim()) || previewContext.blocks.length > 0,
            blockCount: previewContext.blocks.length,
            currentPdfName: previewContext.currentPdfName,
            currentJsonName: previewContext.currentJsonName,
            statusMessage: l('已从阅读历史恢复摘要', 'Summary restored from reading history'),
            sourceKey,
          },
        }));
        return 'loaded';
      }

      if (!force && cachedSummary) {
        setLibraryPreviewStates((current) => ({
          ...current,
          [item.workspaceId]: {
            summary: cachedSummary,
            loading: false,
            error: '',
            hasBlocks: Boolean(documentText.trim()) || previewContext.blocks.length > 0,
            blockCount: previewContext.blocks.length,
            currentPdfName: previewContext.currentPdfName,
            currentJsonName: previewContext.currentJsonName,
            statusMessage: l('已加载缓存摘要', 'Loaded the cached summary'),
            sourceKey,
          },
        }));
        return 'loaded';
      }

      if (!summaryModelPreset || !summaryModelPreset.apiKey.trim() || !summaryModelPreset.baseUrl.trim()) {
        setLibraryPreviewStates((current) => ({
          ...current,
          [item.workspaceId]: {
            summary: null,
            loading: false,
            error: '',
            hasBlocks: Boolean(documentText.trim()) || previewContext.blocks.length > 0,
            blockCount: previewContext.blocks.length,
            currentPdfName: previewContext.currentPdfName,
            currentJsonName: previewContext.currentJsonName,
            statusMessage: l(
              '摘要模型尚未配置完成，请检查 Base URL、模型名称和 API Key。',
              'The summary model is not configured yet. Check the Base URL, model name, and API key.',
            ),
            sourceKey,
          },
        }));
        return 'skipped';
      }

      if (!force && cachedState?.summary && cachedState.sourceKey === sourceKey) {
        setLibraryPreviewStates((current) => ({
          ...current,
          [item.workspaceId]: {
            ...cachedState,
            loading: false,
          },
        }));
        return 'loaded';
      }

      if (!allowGenerate) {
        setLibraryPreviewStates((current) => ({
          ...current,
          [item.workspaceId]: {
            summary: null,
            loading: false,
            error: '',
            hasBlocks: Boolean(documentText.trim()) || previewContext.blocks.length > 0,
            blockCount: previewContext.blocks.length,
            currentPdfName: previewContext.currentPdfName,
            currentJsonName: previewContext.currentJsonName,
            statusMessage: previewContext.blocks.length > 0
              ? l(
                  '结构化内容已就绪，可以手动生成摘要。',
                  'Structured content is ready. You can generate the summary manually.',
                )
              : previewContext.statusMessage,
            sourceKey,
          },
        }));
        return 'skipped';
      }

      const summary = await summarizeDocumentOpenAICompatible({
        baseUrl: summaryModelPreset.baseUrl,
        apiKey: summaryModelPreset.apiKey.trim(),
        model: summaryModelPreset.model,
        title: item.title,
        authors: item.creators || undefined,
        year: item.year || undefined,
        blocks: summaryInputs,
        documentText,
      });

      if (libraryPreviewRequestIdRef.current[item.workspaceId] !== requestId) {
        return 'skipped';
      }

      await savePreviewSummary(item, sourceKey, summary).catch(() => undefined);

      setLibraryPreviewStates((current) => ({
        ...current,
        [item.workspaceId]: {
          summary,
          loading: false,
          error: '',
          hasBlocks: Boolean(documentText.trim()) || previewContext.blocks.length > 0,
          blockCount: previewContext.blocks.length,
          currentPdfName: previewContext.currentPdfName,
          currentJsonName: previewContext.currentJsonName,
          statusMessage: l('AI 摘要已生成', 'AI summary generated'),
          sourceKey,
        },
      }));
      return 'generated';
    } catch (nextError) {
      if (libraryPreviewRequestIdRef.current[item.workspaceId] !== requestId) {
        return 'skipped';
      }

      setLibraryPreviewStates((current) => ({
        ...current,
        [item.workspaceId]: {
          summary: null,
          loading: false,
          error:
            nextError instanceof Error
              ? nextError.message
              : l('生成预览摘要失败', 'Failed to generate the preview summary'),
          hasBlocks: current[item.workspaceId]?.hasBlocks ?? false,
          blockCount: current[item.workspaceId]?.blockCount ?? 0,
          currentPdfName:
            current[item.workspaceId]?.currentPdfName ??
            (item.localPdfPath ? getFileNameFromPath(item.localPdfPath) : noPdfLoadedText),
          currentJsonName: current[item.workspaceId]?.currentJsonName ?? notLoadedText,
          statusMessage: l('生成预览摘要失败', 'Failed to generate the preview summary'),
          sourceKey: current[item.workspaceId]?.sourceKey ?? '',
        },
      }));
      return 'failed';
    }
  };

  const handleBatchMineruParse = useCallback(
    async (options?: { auto?: boolean }) => {
      const auto = options?.auto ?? false;

      if (batchMineruRunningRef.current) {
        return;
      }

      if (!mineruApiToken.trim()) {
        if (!auto) {
          setPreferencesOpen(true);
          setError(l('缺少 MinerU API Token', 'MinerU API Token is missing'));
          setStatusMessage(l('缺少 MinerU API Token', 'MinerU API Token is missing'));
        }
        return;
      }

      if (allKnownItems.length === 0) {
        if (!auto) {
          setStatusMessage(l('当前没有可解析的文献', 'No documents are available for parsing'));
        }
        return;
      }

      const candidates = allKnownItems.filter((item) => {
        const attemptKey = getAutoParseAttemptKey(item);
        return !(auto && autoMineruAttemptedRef.current.has(attemptKey));
      });

      if (candidates.length === 0) {
        if (!auto) {
          setStatusMessage(l('当前没有需要执行解析的文献', 'No documents require parsing right now'));
        }
        return;
      }

      const concurrency = clampBatchConcurrency(settings.libraryBatchConcurrency);

      batchMineruRunningRef.current = true;
      batchMineruPausedRef.current = false;
      batchMineruCancelRequestedRef.current = false;
      setBatchMineruRunning(true);
      setBatchMineruPaused(false);
      setBatchMineruProgress({
        running: true,
        paused: false,
        cancelRequested: false,
        total: candidates.length,
        completed: 0,
        succeeded: 0,
        skipped: 0,
        failed: 0,
        currentLabel: candidates[0]?.title ?? '',
      });

      let parsedCount = 0;
      let existingCount = 0;
      let skippedCount = 0;
      let failedCount = 0;
      let completedCount = 0;
      let successCount = 0;
      let lastErrorMessage = '';
      let cursor = 0;

      const waitForResumeOrCancel = async () => {
        while (batchMineruPausedRef.current && !batchMineruCancelRequestedRef.current) {
          await sleep(120);
        }

        return batchMineruCancelRequestedRef.current;
      };

      const updateProgress = (currentLabel: string) => {
        setBatchMineruProgress({
          running: true,
          paused: batchMineruPausedRef.current,
          cancelRequested: batchMineruCancelRequestedRef.current,
          total: candidates.length,
          completed: completedCount,
          succeeded: successCount,
          skipped: skippedCount,
          failed: failedCount,
          currentLabel,
        });
      };

      try {
        const runWorker = async () => {
          while (true) {
            if (await waitForResumeOrCancel()) {
              return;
            }

            const currentIndex = cursor;
            cursor += 1;

            if (currentIndex >= candidates.length || batchMineruCancelRequestedRef.current) {
              return;
            }

            const item = candidates[currentIndex];
            const attemptKey = getAutoParseAttemptKey(item);
            const currentLabel = `${currentIndex + 1}/${candidates.length} ${item.title}`;

            if (!auto) {
              setStatusMessage(
                l(
                  `批量 MinerU 解析中：${currentLabel}`,
                  `Running MinerU batch parsing: ${currentLabel}`,
                ),
              );
            }

            updateProgress(currentLabel);

            try {
              const existingParse = await findExistingMineruJson(item);

              if (existingParse) {
                syncLibraryParsedState(
                  item,
                  existingParse.jsonText,
                  existingParse.path,
                  l('已复用已有的 MinerU 结果', 'Reused the existing MinerU result'),
                );
                existingCount += 1;
                successCount += 1;
                continue;
              }

              const pdfPath = item.localPdfPath?.trim() ?? '';

              if (!pdfPath) {
                skippedCount += 1;
                continue;
              }

              const cachePaths = settings.mineruCacheDir.trim()
                ? buildMineruCachePaths(settings.mineruCacheDir.trim(), item)
                : null;
              const result = await runMineruCloudParse({
                apiToken: mineruApiToken.trim(),
                pdfPath,
                extractDir: cachePaths?.directory,
                language: 'ch',
                modelVersion: 'vlm',
                enableFormula: true,
                enableTable: true,
                isOcr: false,
                timeoutSecs: 900,
                pollIntervalSecs: 5,
              });
              const jsonText = result.contentJsonText ?? result.middleJsonText;

              if (!jsonText?.trim()) {
                throw new Error(
                  l(
                    'MinerU 未返回可用的 JSON 结果',
                    'MinerU did not return a usable JSON result',
                  ),
                );
              }

              const savedPaths = await saveLibraryMineruParseCache({
                item,
                pdfPath,
                sourceKind: 'cloud',
                contentJsonText: result.contentJsonText,
                middleJsonText: result.middleJsonText,
                markdownText: result.markdownText,
                batchId: result.batchId,
                dataId: result.dataId,
                fileName: result.fileName,
                zipEntries: result.zipEntries,
              }).catch(() => null);

              const resolvedJsonPath =
                result.contentJsonPath ||
                result.middleJsonPath ||
                (savedPaths
                  ? result.contentJsonText?.trim()
                    ? savedPaths.contentJsonPath
                    : savedPaths.middleJsonPath
                  : 'content_list_v2.json');
              const status = savedPaths
                ? l(
                    `已完成 MinerU 解析并写入缓存：${savedPaths.directory}`,
                    `MinerU parsing finished and was cached in: ${savedPaths.directory}`,
                  )
                : l('已完成 MinerU 解析', 'MinerU parsing finished');

              syncLibraryParsedState(item, jsonText, resolvedJsonPath, status);
              parsedCount += 1;
              successCount += 1;
            } catch (nextError) {
              failedCount += 1;
              lastErrorMessage =
                nextError instanceof Error
                  ? nextError.message
                  : l('MinerU 解析失败', 'MinerU parsing failed');
            } finally {
              completedCount += 1;
              autoMineruAttemptedRef.current.add(attemptKey);
              updateProgress(currentLabel);
            }
          }
        };

        await Promise.all(
          Array.from({ length: Math.min(concurrency, candidates.length) }, () => runWorker()),
        );
      } finally {
        const wasCancelled = batchMineruCancelRequestedRef.current;
        batchMineruRunningRef.current = false;
        batchMineruPausedRef.current = false;
        setBatchMineruRunning(false);
        setBatchMineruPaused(false);
        setBatchMineruProgress({
          running: false,
          paused: false,
          cancelRequested: wasCancelled,
          total: candidates.length,
          completed: completedCount,
          succeeded: successCount,
          skipped: skippedCount,
          failed: failedCount,
          currentLabel:
            wasCancelled
              ? l(
                  `MinerU 批处理已取消，已完成 ${completedCount}/${candidates.length}`,
                  `MinerU batch cancelled after ${completedCount}/${candidates.length}`,
                )
              : candidates.length > 0
              ? l(
                  `批量解析进度 ${completedCount}/${candidates.length}`,
                  `Batch parse progress ${completedCount}/${candidates.length}`,
                )
              : '',
        });
      }

      if (!auto) {
        if (lastErrorMessage && !batchMineruCancelRequestedRef.current) {
          setError(lastErrorMessage);
        }

        setStatusMessage(
          batchMineruCancelRequestedRef.current
            ? l(
                `MinerU 批处理已取消：新增 ${parsedCount}，复用 ${existingCount}，跳过 ${skippedCount}，失败 ${failedCount}`,
                `MinerU batch cancelled: parsed ${parsedCount}, reused ${existingCount}, skipped ${skippedCount}, failed ${failedCount}`,
              )
            : l(
                `MinerU 批处理完成：新增 ${parsedCount}，复用 ${existingCount}，跳过 ${skippedCount}，失败 ${failedCount}`,
                `MinerU batch finished: parsed ${parsedCount}, reused ${existingCount}, skipped ${skippedCount}, failed ${failedCount}`,
              ),
        );
      }
    },
    [
      allKnownItems,
      findExistingMineruJson,
      mineruApiToken,
      saveLibraryMineruParseCache,
      settings.libraryBatchConcurrency,
      settings.mineruCacheDir,
      syncLibraryParsedState,
    ],
  );

  const handleBatchGenerateSummaries = useCallback(
    async (options?: { auto?: boolean }) => {
      const auto = options?.auto ?? false;

      if (batchSummaryRunningRef.current) {
        return;
      }

      if (!summaryConfigured) {
        if (!auto) {
          setPreferencesOpen(true);
          setError(l('缺少摘要模型配置', 'Summary model configuration is missing'));
          setStatusMessage(l('缺少摘要模型配置', 'Summary model configuration is missing'));
        }
        return;
      }

      if (allKnownItems.length === 0) {
        if (!auto) {
          setStatusMessage(l('当前没有可生成摘要的文献', 'No documents are available for summary generation'));
        }
        return;
      }

      const concurrency = clampBatchConcurrency(settings.libraryBatchConcurrency);
      const preparedCandidates = await Promise.all(
        allKnownItems.map(async (item) => {
          const parseResult =
            settings.summarySourceMode === 'mineru-markdown'
              ? await findExistingMineruJson(item)
              : null;
          const hasParse = Boolean(parseResult);
          const attemptKey = getAutoSummaryAttemptKey(
            item,
            settings.summarySourceMode,
            hasParse,
          );

          return {
            item,
            hasParse,
            attemptKey,
          };
        }),
      );
      const candidates = preparedCandidates.filter(
        ({ attemptKey }) => !(auto && autoSummaryAttemptedRef.current.has(attemptKey)),
      );

      if (candidates.length === 0) {
        if (!auto) {
          setStatusMessage(l('当前没有需要生成摘要的文献', 'No documents require summary generation right now'));
        }
        return;
      }

      batchSummaryRunningRef.current = true;
      batchSummaryPausedRef.current = false;
      batchSummaryCancelRequestedRef.current = false;
      setBatchSummaryRunning(true);
      setBatchSummaryPaused(false);
      setBatchSummaryProgress({
        running: true,
        paused: false,
        cancelRequested: false,
        total: candidates.length,
        completed: 0,
        succeeded: 0,
        skipped: 0,
        failed: 0,
        currentLabel: candidates[0]?.item.title ?? '',
      });

      let succeededCount = 0;
      let skippedCount = 0;
      let failedCount = 0;
      let completedCount = 0;
      let cursor = 0;

      const waitForResumeOrCancel = async () => {
        while (batchSummaryPausedRef.current && !batchSummaryCancelRequestedRef.current) {
          await sleep(120);
        }

        return batchSummaryCancelRequestedRef.current;
      };

      const updateProgress = (currentLabel: string) => {
        setBatchSummaryProgress({
          running: true,
          paused: batchSummaryPausedRef.current,
          cancelRequested: batchSummaryCancelRequestedRef.current,
          total: candidates.length,
          completed: completedCount,
          succeeded: succeededCount,
          skipped: skippedCount,
          failed: failedCount,
          currentLabel,
        });
      };

      try {
        const runWorker = async () => {
          while (true) {
            if (await waitForResumeOrCancel()) {
              return;
            }

            const currentIndex = cursor;
            cursor += 1;

            if (currentIndex >= candidates.length || batchSummaryCancelRequestedRef.current) {
              return;
            }

            const candidate = candidates[currentIndex];
            const currentLabel = `${currentIndex + 1}/${candidates.length} ${candidate.item.title}`;

            if (!auto) {
              setStatusMessage(
                l(
                  `正在批量生成摘要：${currentLabel}`,
                  `Generating summaries in batch: ${currentLabel}`,
                ),
              );
            }

            updateProgress(currentLabel);

            try {
              if (
                settings.summarySourceMode === 'pdf-text' &&
                !candidate.item.localPdfPath?.trim()
              ) {
                skippedCount += 1;
                continue;
              }

              if (settings.summarySourceMode === 'mineru-markdown' && !candidate.hasParse) {
                skippedCount += 1;
                continue;
              }

              const outcome = await generateLibraryPreview(candidate.item, false, {
                allowGenerate: true,
              });

              if (outcome === 'failed') {
                failedCount += 1;
              } else if (outcome === 'skipped') {
                skippedCount += 1;
              } else {
                succeededCount += 1;
              }
            } finally {
              completedCount += 1;
              autoSummaryAttemptedRef.current.add(candidate.attemptKey);
              updateProgress(currentLabel);
            }
          }
        };

        await Promise.all(
          Array.from({ length: Math.min(concurrency, candidates.length) }, () => runWorker()),
        );
      } finally {
        const wasCancelled = batchSummaryCancelRequestedRef.current;
        batchSummaryRunningRef.current = false;
        batchSummaryPausedRef.current = false;
        setBatchSummaryRunning(false);
        setBatchSummaryPaused(false);
        setBatchSummaryProgress({
          running: false,
          paused: false,
          cancelRequested: wasCancelled,
          total: candidates.length,
          completed: completedCount,
          succeeded: succeededCount,
          skipped: skippedCount,
          failed: failedCount,
          currentLabel:
            wasCancelled
              ? l(
                  `批量摘要已取消，已完成 ${completedCount}/${candidates.length}`,
                  `Batch summary cancelled after ${completedCount}/${candidates.length}`,
                )
              : candidates.length > 0
              ? l(
                  `批量摘要进度 ${completedCount}/${candidates.length}`,
                  `Batch summary progress ${completedCount}/${candidates.length}`,
                )
              : '',
        });
      }

      if (!auto) {
        setStatusMessage(
          batchSummaryCancelRequestedRef.current
            ? l(
                `摘要批处理已取消：成功 ${succeededCount}，跳过 ${skippedCount}，失败 ${failedCount}`,
                `Summary batch cancelled: succeeded ${succeededCount}, skipped ${skippedCount}, failed ${failedCount}`,
              )
            : l(
                `摘要批处理完成：成功 ${succeededCount}，跳过 ${skippedCount}，失败 ${failedCount}`,
                `Summary batch finished: succeeded ${succeededCount}, skipped ${skippedCount}, failed ${failedCount}`,
              ),
        );
      }
    },
    [
      allKnownItems,
      findExistingMineruJson,
      generateLibraryPreview,
      settings.libraryBatchConcurrency,
      settings.summarySourceMode,
      summaryConfigured,
    ],
  );

  const handleOpenStandalonePdf = async () => {
    setError('');

    try {
      const source = await selectLocalPdfSource();

      if (!source || source.kind !== 'local-path') {
        setStatusMessage(l('未选择 PDF 文件', 'No PDF file selected'));
        return;
      }

      const standaloneItem = createStandaloneItem(source.path, settings.uiLanguage);

      setStandaloneItems((current) => {
        const existingItems = current.filter(
          (item) => item.workspaceId !== standaloneItem.workspaceId,
        );
        return [standaloneItem, ...existingItems];
      });
      setSelectedSectionKey('standalone');
      setSelectedLibraryItemId(standaloneItem.workspaceId);
      openTab(standaloneItem.workspaceId, standaloneItem.title);
    } catch (nextError) {
      const message =
        nextError instanceof Error
          ? nextError.message
          : l('打开独立 PDF 失败', 'Failed to open the standalone PDF');
      setError(message);
      setStatusMessage(message);
    }
  };

  const handleLibraryItemClick = (item: WorkspaceItem) => {
    if (libraryItemClickTimerRef.current) {
      window.clearTimeout(libraryItemClickTimerRef.current);
    }

    libraryItemClickTimerRef.current = window.setTimeout(() => {
      libraryItemClickTimerRef.current = null;
      setSelectedLibraryItemId(item.workspaceId);
      setStatusMessage(l(`已选择文献：${item.title}`, `Selected document: ${item.title}`));
    }, 220);
  };

  const handleLibraryItemDoubleClick = (item: WorkspaceItem) => {
    if (libraryItemClickTimerRef.current) {
      window.clearTimeout(libraryItemClickTimerRef.current);
      libraryItemClickTimerRef.current = null;
    }

    setSelectedLibraryItemId(item.workspaceId);
    openTab(item.workspaceId, item.title);
  };

  const handleWindowMinimize = () => {
    void appWindow.minimize().catch((nextError) => {
      const message = nextError instanceof Error ? nextError.message : '窗口最小化失败';
      setError(message);
      setStatusMessage(message);
    });
  };

  const handleWindowToggleMaximize = () => {
    void appWindow.toggleMaximize().catch((nextError) => {
      const message = nextError instanceof Error ? nextError.message : '窗口缩放失败';
      setError(message);
      setStatusMessage(message);
    });
  };

  const handleWindowClose = () => {
    void appWindow.close().catch((nextError) => {
      const message =
        nextError instanceof Error ? nextError.message : l('关闭窗口失败', 'Failed to close the window');
      setError(message);
      setStatusMessage(message);
    });
  };

  const handleSelectMineruCacheDir = async () => {
    try {
      const selectedDir = await selectDirectory(
        l('选择 MinerU 缓存目录', 'Select the MinerU cache directory'),
      );

      if (!selectedDir) {
        setStatusMessage(l('未选择 MinerU 缓存目录', 'No MinerU cache directory selected'));
        return;
      }

      setSettings((current) => ({
        ...current,
        mineruCacheDir: selectedDir,
      }));
      setStatusMessage(
        l(
          `已更新 MinerU 缓存目录：${truncateMiddle(selectedDir, 48)}`,
          `Updated the MinerU cache directory: ${truncateMiddle(selectedDir, 48)}`,
        ),
      );
    } catch (nextError) {
      const message =
        nextError instanceof Error
          ? nextError.message
          : l(
              '选择 MinerU 缓存目录失败',
              'Failed to select the MinerU cache directory',
            );
      setError(message);
      setStatusMessage(message);
    }
  };

  const handleSelectRemotePdfDownloadDir = async () => {
    try {
      const selectedDir = await selectDirectory(
        l('选择远程 PDF 下载目录', 'Select the remote PDF download directory'),
      );

      if (!selectedDir) {
        setStatusMessage(
          l('未选择远程 PDF 下载目录', 'No remote PDF download directory selected'),
        );
        return;
      }

      setSettings((current) => ({
        ...current,
        remotePdfDownloadDir: selectedDir,
      }));
      setStatusMessage(
        l(
          `已更新远程 PDF 下载目录：${truncateMiddle(selectedDir, 48)}`,
          `Updated the remote PDF download directory: ${truncateMiddle(selectedDir, 48)}`,
        ),
      );
    } catch (nextError) {
      const message =
        nextError instanceof Error
          ? nextError.message
          : l(
              '选择远程 PDF 下载目录失败',
              'Failed to select the remote PDF download directory',
            );
      setError(message);
      setStatusMessage(message);
    }
  };

  const handleTestLlmConnection = async (
    preset?: QaModelPreset,
  ): Promise<OpenAICompatibleTestResult> => {
    setError('');
    setStatusMessage(l('正在测试 AI 接口连接...', 'Testing the AI endpoint connection...'));

    try {
      const targetPreset = preset ?? translationModelPreset;

      if (!targetPreset) {
        throw new Error(
          l(
            '没有可用于测试的模型预设，请先完成模型配置。',
            'No model preset is available for testing. Configure a model first.',
          ),
        );
      }

      const result = await testOpenAICompatibleChat({
        baseUrl: targetPreset.baseUrl,
        apiKey: targetPreset.apiKey.trim(),
        model: targetPreset.model,
      });

      if (result.ok) {
        setError('');
        setStatusMessage(
          l(
            `AI 接口连接成功：${result.responseModel || result.model}`,
            `AI endpoint connected: ${result.responseModel || result.model}`,
          ),
        );
      } else {
        setError(result.message);
        setStatusMessage(
          l(`AI 接口连接失败：${result.message}`, `AI endpoint connection failed: ${result.message}`),
        );
      }

      return result;
    } catch (nextError) {
      const message =
        nextError instanceof Error
          ? nextError.message
          : l('测试 AI 接口失败', 'Failed to test the AI endpoint');

      setError(message);
      setStatusMessage(message);
      throw nextError;
    }
  };

  const handleBridgeStateChange = useCallback((tabId: string, bridge: ReaderTabBridgeState | null) => {
    setReaderBridges((current) => {
      if (!bridge) {
        if (!(tabId in current)) {
          return current;
        }

        const next = { ...current };
        delete next[tabId];
        return next;
      }

      return {
        ...current,
        [tabId]: bridge,
      };
    });
  }, []);

  const handlePreviewCloudParse = useCallback(() => {
    if (!selectedLibraryItem) {
      return;
    }

    const tabId = openTab(selectedLibraryItem.workspaceId, selectedLibraryItem.title);
    const bridge = readerBridges[tabId];

    if (bridge) {
      bridge.onCloudParse();
      return;
    }

    setPendingCloudParseTabId(tabId);
  }, [openTab, readerBridges, selectedLibraryItem]);

  const handlePreviewTranslateDocument = useCallback(() => {
    if (!selectedLibraryItem) {
      return;
    }

    const tabId = openTab(selectedLibraryItem.workspaceId, selectedLibraryItem.title);
    const bridge = readerBridges[tabId];

    if (bridge) {
      bridge.onTranslate();
      return;
    }

    setPendingTranslateTabId(tabId);
  }, [openTab, readerBridges, selectedLibraryItem]);

  const handleToggleBatchMineruPause = useCallback(() => {
    if (!batchMineruRunningRef.current) {
      return;
    }

    const nextPaused = !batchMineruPausedRef.current;
    batchMineruPausedRef.current = nextPaused;
    setBatchMineruPaused(nextPaused);
    setBatchMineruProgress((current) =>
      current.running
        ? {
            ...current,
            paused: nextPaused,
            cancelRequested: batchMineruCancelRequestedRef.current,
          }
        : current,
    );
    setStatusMessage(
      nextPaused
        ? l('已暂停 MinerU 批量解析', 'Paused the MinerU batch parsing')
        : l('已继续 MinerU 批量解析', 'Resumed the MinerU batch parsing'),
    );
  }, [l]);

  const handleCancelBatchMineru = useCallback(() => {
    if (!batchMineruRunningRef.current || batchMineruCancelRequestedRef.current) {
      return;
    }

    batchMineruCancelRequestedRef.current = true;
    batchMineruPausedRef.current = false;
    setBatchMineruPaused(false);
    setBatchMineruProgress((current) =>
      current.running
        ? {
            ...current,
            paused: false,
            cancelRequested: true,
            currentLabel:
              current.currentLabel ||
              l('正在等待当前任务结束后取消…', 'Waiting for the current task to finish before cancelling...'),
          }
        : current,
    );
    setStatusMessage(
      l(
        '正在取消 MinerU 批量解析，当前进行中的任务完成后将停止。',
        'Cancelling the MinerU batch parsing. It will stop after the current tasks finish.',
      ),
    );
  }, [l]);

  const handleToggleBatchSummaryPause = useCallback(() => {
    if (!batchSummaryRunningRef.current) {
      return;
    }

    const nextPaused = !batchSummaryPausedRef.current;
    batchSummaryPausedRef.current = nextPaused;
    setBatchSummaryPaused(nextPaused);
    setBatchSummaryProgress((current) =>
      current.running
        ? {
            ...current,
            paused: nextPaused,
            cancelRequested: batchSummaryCancelRequestedRef.current,
          }
        : current,
    );
    setStatusMessage(
      nextPaused
        ? l('已暂停批量摘要生成', 'Paused the batch summary generation')
        : l('已继续批量摘要生成', 'Resumed the batch summary generation'),
    );
  }, [l]);

  const handleCancelBatchSummary = useCallback(() => {
    if (!batchSummaryRunningRef.current || batchSummaryCancelRequestedRef.current) {
      return;
    }

    batchSummaryCancelRequestedRef.current = true;
    batchSummaryPausedRef.current = false;
    setBatchSummaryPaused(false);
    setBatchSummaryProgress((current) =>
      current.running
        ? {
            ...current,
            paused: false,
            cancelRequested: true,
            currentLabel:
              current.currentLabel ||
              l('正在等待当前任务结束后取消…', 'Waiting for the current task to finish before cancelling...'),
          }
        : current,
    );
    setStatusMessage(
      l(
        '正在取消批量摘要生成，当前进行中的任务完成后将停止。',
        'Cancelling the batch summary generation. It will stop after the current tasks finish.',
      ),
    );
  }, [l]);

  const updateSetting = useCallback(<Key extends keyof ReaderSettings>(
    key: Key,
    value: ReaderSettings[Key],
  ) => {
    setSettings((current) =>
      normalizeReaderSettings({
        ...current,
        [key]: key === 'translationDisplayMode' ? 'translated' : value,
      }),
    );
  }, []);

  const updateReaderSecret = useCallback(<Key extends keyof ReaderSecrets>(
    key: Key,
    value: ReaderSecrets[Key],
  ) => {
    setReaderSecrets((current) => ({
      ...current,
      [key]: value,
    }));
  }, []);

  const updateQaModelPreset = useCallback((presetId: string, patch: Partial<QaModelPreset>) => {
    setReaderSecrets((current) => ({
      ...current,
      qaModelPresets: current.qaModelPresets.map((preset) => {
        if (preset.id !== presetId) {
          return preset;
        }

        const nextModel = Object.prototype.hasOwnProperty.call(patch, 'model')
          ? patch.model ?? ''
          : preset.model;
        const hasExplicitLabel = Object.prototype.hasOwnProperty.call(patch, 'label');
        const nextLabelSource = hasExplicitLabel ? patch.label ?? '' : preset.label;
        const currentLabelCustomized = preset.labelCustomized ?? false;
        const nextLabelCustomized =
          patch.labelCustomized ??
          (hasExplicitLabel
            ? nextLabelSource.trim() !== '' && nextLabelSource.trim() !== nextModel.trim()
            : currentLabelCustomized);
        const nextLabel =
          hasExplicitLabel
            ? nextLabelSource || (!nextLabelCustomized ? nextModel : '')
            : Object.prototype.hasOwnProperty.call(patch, 'model') &&
                (!currentLabelCustomized || preset.label.trim() === preset.model.trim())
              ? nextModel
              : preset.label;

        return createQaPreset({
          ...preset,
          ...patch,
          model: nextModel,
          label: nextLabel,
          labelCustomized: nextLabelCustomized,
        });
      }),
    }));
  }, []);

  const addQaModelPreset = useCallback(() => {
    const nextPreset = createQaPreset({
      baseUrl: '',
      model: '',
      label: '',
      apiKey: '',
      labelCustomized: false,
    });

    setReaderSecrets((current) => ({
      ...current,
      qaModelPresets: [...current.qaModelPresets, nextPreset],
    }));
  }, []);

  const removeQaModelPreset = useCallback((presetId: string) => {
    const nextPresets = qaModelPresets.filter((preset) => preset.id !== presetId);

    if (nextPresets.length === 0 || nextPresets.length === qaModelPresets.length) {
      return;
    }

    setReaderSecrets((current) => ({
      ...current,
      qaModelPresets: nextPresets,
    }));

    const fallbackPresetId = nextPresets[0]?.id ?? DEFAULT_QA_PRESET_ID;

    setSettings((current) => {
      return {
        ...current,
        qaActivePresetId:
          current.qaActivePresetId === presetId ? fallbackPresetId : current.qaActivePresetId,
        translationModelPresetId:
          current.translationModelPresetId === presetId
            ? fallbackPresetId
            : current.translationModelPresetId,
        selectionTranslationModelPresetId:
          current.selectionTranslationModelPresetId === presetId
            ? fallbackPresetId
            : current.selectionTranslationModelPresetId,
        summaryModelPresetId:
          current.summaryModelPresetId === presetId
            ? fallbackPresetId
            : current.summaryModelPresetId,
      };
    });
  }, [qaModelPresets]);

  useEffect(() => {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(SECRETS_STORAGE_KEY, JSON.stringify(readerSecrets));
  }, [readerSecrets]);

  useEffect(() => {
    if (qaModelPresets.some((preset) => preset.id === settings.qaActivePresetId)) {
      return;
    }

    const fallbackPresetId = qaModelPresets[0]?.id ?? DEFAULT_QA_PRESET_ID;

    setSettings((current) => ({
      ...current,
      qaActivePresetId: fallbackPresetId,
    }));
  }, [qaModelPresets, settings.qaActivePresetId]);

  useEffect(() => {
    localStorage.setItem(LEFT_SIDEBAR_COLLAPSED_STORAGE_KEY, String(leftSidebarCollapsed));
  }, [leftSidebarCollapsed]);

  useEffect(() => {
    if (!configHydrated || !appDefaultPaths) {
      return;
    }

    const nextConfig: ReaderConfigFile = {
      version: READER_CONFIG_VERSION,
      settings,
      secrets: readerSecrets,
      zoteroLocalDataDir,
      leftSidebarCollapsed,
    };

    void writeLocalTextFile(appDefaultPaths.configPath, JSON.stringify(nextConfig, null, 2)).catch(
      () => undefined,
    );
  }, [
    appDefaultPaths,
    configHydrated,
    leftSidebarCollapsed,
    readerSecrets,
    settings,
    zoteroLocalDataDir,
  ]);

  useEffect(() => {
    if (!pendingCloudParseTabId) {
      return;
    }

    const bridge = readerBridges[pendingCloudParseTabId];

    if (!bridge) {
      return;
    }

    bridge.onCloudParse();
    setPendingCloudParseTabId(null);
  }, [pendingCloudParseTabId, readerBridges]);

  useEffect(() => {
    if (!pendingTranslateTabId) {
      return;
    }

    const bridge = readerBridges[pendingTranslateTabId];

    if (!bridge) {
      return;
    }

    bridge.onTranslate();
    setPendingTranslateTabId(null);
  }, [pendingTranslateTabId, readerBridges]);

  useEffect(() => {
    if (!configHydrated) {
      return;
    }

    void loadLocalLibrary(undefined, true);
  }, [configHydrated]);

  useEffect(() => {
    autoMineruAttemptedRef.current.clear();
  }, [
    mineruApiToken,
    settings.autoLoadSiblingJson,
    settings.autoMineruParse,
    settings.mineruCacheDir,
  ]);

  useEffect(() => {
    autoSummaryAttemptedRef.current.clear();
  }, [
    settings.autoGenerateSummary,
    settings.autoLoadSiblingJson,
    settings.mineruCacheDir,
    settings.summarySourceMode,
    summaryConfigured,
  ]);

  useEffect(() => {
    if (activeTabId !== HOME_TAB_ID || !selectedLibraryItem) {
      return;
    }

    void generateLibraryPreview(selectedLibraryItem, false, { allowGenerate: false });
  }, [
    activeTabId,
    selectedLibraryItem?.workspaceId,
    settings.mineruCacheDir,
    settings.autoLoadSiblingJson,
    settings.summaryBaseUrl,
    settings.summaryModel,
    settings.summarySourceMode,
    summaryApiKey,
  ]);

  useEffect(() => {
    if (!configHydrated || !settings.autoMineruParse) {
      return;
    }

    if (batchMineruRunningRef.current) {
      return;
    }

    void handleBatchMineruParse({ auto: true });
  }, [
    configHydrated,
    settings.autoMineruParse,
    allKnownItems,
  ]);

  useEffect(() => {
    if (!configHydrated || !settings.autoGenerateSummary || !summaryConfigured) {
      return;
    }

    if (batchSummaryRunningRef.current) {
      return;
    }

    void handleBatchGenerateSummaries({ auto: true });
  }, [
    allKnownItems,
    configHydrated,
    itemParseStatusMap,
    settings.autoGenerateSummary,
    summaryConfigured,
  ]);

  useEffect(() => {
    if (!selectedSectionKey.startsWith('collection:')) {
      return;
    }

    const collectionKey = selectedSectionKey.slice('collection:'.length);
    void ensureCollectionItems(collectionKey);
  }, [selectedSectionKey, zoteroLocalDataDir]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'f') {
        if (activeTab?.type !== 'library') {
          return;
        }

        event.preventDefault();
        librarySearchInputRef.current?.focus();
        return;
      }

      if (event.key === 'Escape' && preferencesOpen) {
        setPreferencesOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeTab?.type, preferencesOpen]);

  useEffect(() => {
    return () => {
      if (libraryItemClickTimerRef.current) {
        window.clearTimeout(libraryItemClickTimerRef.current);
      }
    };
  }, []);

  return (
    <AppLocaleProvider value={settings.uiLanguage}>
      <div className="relative h-full min-h-0 overflow-hidden bg-[linear-gradient(180deg,#eef2f8,#e7edf5)] text-slate-900">
      <div className="flex h-full min-h-0 flex-col rounded-[28px] border border-white/70 bg-white/55 shadow-[0_26px_70px_rgba(15,23,42,0.10)] backdrop-blur-xl">
        <header className="flex h-14 shrink-0 items-center justify-between border-b border-slate-200/80 bg-white/72 px-4 backdrop-blur-xl">
          <div
            className="flex min-w-0 items-center gap-3"
            data-tauri-drag-region
            onDoubleClick={handleWindowToggleMaximize}
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-slate-900 text-white">
              <BookOpenText className="h-4 w-4" strokeWidth={1.9} />
            </div>
            <div className="min-w-0">
              <div className="truncate text-sm font-semibold text-slate-900">PaperQuay</div>
              <div className="truncate text-xs text-slate-500">
                {l(
                  '桌面优先的论文阅读与研究工作台',
                  'A desktop-first workspace for paper reading and research analysis',
                )}
              </div>
            </div>
          </div>

          <div
            className="mx-4 min-w-8 flex-1 self-stretch"
            data-tauri-drag-region
            onDoubleClick={handleWindowToggleMaximize}
          />

          <div className="flex items-center gap-2">
            <button
              hidden
              type="button"
              onClick={() => setLeftSidebarCollapsed((current) => !current)}
              className="inline-flex items-center rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 transition-all duration-200 hover:border-slate-300 hover:bg-slate-50"
            >
              {leftSidebarCollapsed ? (
                <PanelLeftOpen className="mr-2 h-4 w-4" strokeWidth={1.8} />
              ) : (
                <PanelLeftClose className="mr-2 h-4 w-4" strokeWidth={1.8} />
              )}
              {leftSidebarCollapsed ? l('展开文库', 'Expand Library') : l('折叠文库', 'Collapse Library')}
            </button>
            <button
              hidden
              type="button"
              onClick={handleOpenStandalonePdf}
              className="inline-flex items-center rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 transition-all duration-200 hover:border-slate-300 hover:bg-slate-50"
            >
              <Library className="mr-2 h-4 w-4" strokeWidth={1.8} />
              {l('打开 PDF', 'Open PDF')}
            </button>
            <button
              type="button"
              onClick={handleOpenPreferences}
              className="inline-flex items-center rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 transition-all duration-200 hover:border-slate-300 hover:bg-slate-50"
            >
              <Settings2 className="mr-2 h-4 w-4" strokeWidth={1.8} />
              {l('设置', 'Settings')}
            </button>
            <div className="flex items-center rounded-xl border border-slate-200 bg-white p-1">
              <button
                type="button"
                onClick={handleWindowMinimize}
                className="rounded-lg p-2 text-slate-500 transition-all duration-200 hover:bg-slate-100 hover:text-slate-700"
                aria-label={l('最小化窗口', 'Minimize Window')}
              >
                <Minus className="h-4 w-4" strokeWidth={1.9} />
              </button>
              <button
                type="button"
                onClick={handleWindowToggleMaximize}
                className="rounded-lg p-2 text-slate-500 transition-all duration-200 hover:bg-slate-100 hover:text-slate-700"
                aria-label={l('切换窗口缩放', 'Toggle Window Maximize')}
              >
                <Square className="h-3.5 w-3.5" strokeWidth={1.9} />
              </button>
              <button
                type="button"
                onClick={handleWindowClose}
                className="rounded-lg p-2 text-slate-500 transition-all duration-200 hover:bg-rose-50 hover:text-rose-600"
                aria-label={l('关闭窗口', 'Close Window')}
              >
                <X className="h-4 w-4" strokeWidth={1.9} />
              </button>
            </div>
          </div>
        </header>

        <TabBar
          tabs={tabs}
          activeTabId={activeTabId}
          onSelect={setActiveTab}
          onClose={closeTab}
        />

        <main className="relative min-h-0 flex-1 overflow-hidden">
          <div className="h-full min-h-0" hidden={activeTabId !== HOME_TAB_ID}>
            <LibraryWorkspace
              leftSidebarCollapsed={leftSidebarCollapsed}
              zoteroLocalDataDir={zoteroLocalDataDir}
              zoteroAllItemsCount={zoteroAllItems.length}
              standaloneItemsCount={standaloneItems.length}
              flattenedCollections={flattenedCollections}
              selectedSectionKey={selectedSectionKey}
              selectedSectionTitle={selectedSectionTitle}
              visibleItems={visibleItems}
              itemParseStatusMap={itemParseStatusMap}
              selectedItemId={selectedItemId}
              librarySearchQuery={librarySearchQuery}
              libraryDisplayMode={libraryDisplayMode}
              libraryLoading={libraryLoading}
              libraryLoadingSection={libraryLoadingSection}
              statusMessage={statusMessage}
              error={error}
              librarySearchInputRef={librarySearchInputRef}
              onToggleLeftSidebar={() => setLeftSidebarCollapsed((current) => !current)}
              onSelectSection={(sectionKey) => void handleSelectLibrarySection(sectionKey)}
              onSearchQueryChange={setLibrarySearchQuery}
              onDisplayModeChange={setLibraryDisplayMode}
              onOpenStandalonePdf={() => void handleOpenStandalonePdf()}
              onReloadLocalZotero={() => void handleReloadLocalZotero()}
              onOpenPreferences={handleOpenPreferences}
              onItemClick={handleLibraryItemClick}
              onItemDoubleClick={handleLibraryItemDoubleClick}
              previewPane={
                <LibraryPreviewPane
                  selectedItem={selectedLibraryItem}
                  currentPdfName={activeLibraryPreviewState.currentPdfName}
                  currentJsonName={activeLibraryPreviewState.currentJsonName}
                  hasBlocks={activeLibraryPreviewState.hasBlocks}
                  blockCount={activeLibraryPreviewState.blockCount}
                  statusMessage={activeLibraryPreviewState.statusMessage}
                  summary={activeLibraryPreviewState.summary}
                  loading={activeLibraryPreviewState.loading}
                  error={activeLibraryPreviewState.error}
                  aiConfigured={Boolean(
                    summaryModelPreset &&
                      summaryModelPreset.apiKey.trim() &&
                      summaryModelPreset.baseUrl.trim() &&
                      summaryModelPreset.model.trim(),
                  )}
                  onOpenReader={() => {
                    if (selectedLibraryItem) {
                      openTab(selectedLibraryItem.workspaceId, selectedLibraryItem.title);
                    }
                  }}
                  onTranslateDocument={handlePreviewTranslateDocument}
                  onCloudParse={handlePreviewCloudParse}
                  onGenerateSummary={() => {
                    if (selectedLibraryItem) {
                      void generateLibraryPreview(selectedLibraryItem, true, { allowGenerate: true });
                    }
                  }}
                />
              }
            />
          </div>

          {readerTabs.map((tab) => {
            const item = workspaceItemMap.get(tab.documentId);

            if (!item) {
              return null;
            }

            return (
              <div key={tab.id} className="h-full min-h-0" hidden={tab.id !== activeTabId}>
                <DocumentReaderTab
                  tabId={tab.id}
                  document={item}
                  isActive={tab.id === activeTabId}
                  settings={settings}
                  zoteroLocalDataDir={zoteroLocalDataDir}
                  mineruApiToken={mineruApiToken}
                  translationApiKey={translationApiKey}
                  summaryApiKey={summaryApiKey}
                  qaModelPresets={qaModelPresets}
                  zoteroApiKey={zoteroApiKey}
                  zoteroUserId={zoteroUserId}
                  onZoteroUserIdChange={(value) => updateReaderSecret('zoteroUserId', value)}
                  onQaActivePresetChange={(presetId) => updateSetting('qaActivePresetId', presetId)}
                  onDocumentResolved={handleWorkspaceItemResolved}
                  onLibraryPreviewSync={handleLibraryPreviewSync}
                  onOpenPreferences={handleOpenPreferences}
                  onOpenStandalonePdf={() => void handleOpenStandalonePdf()}
                  onBridgeStateChange={handleBridgeStateChange}
                />
              </div>
            );
          })}
        </main>
      </div>

      <PreferencesWindow
        open={preferencesOpen}
        onClose={() => setPreferencesOpen(false)}
        settings={settings}
        zoteroLocalDataDir={zoteroLocalDataDir}
        mineruApiToken={mineruApiToken}
        translationApiKey={translationApiKey}
        summaryApiKey={summaryApiKey}
        qaModelPresets={qaModelPresets}
        zoteroApiKey={zoteroApiKey}
        zoteroUserId={zoteroUserId}
        libraryLoading={libraryLoading}
        translating={activeReaderBridge?.translating ?? false}
        translatedCount={activeReaderBridge?.translatedCount ?? 0}
        onSettingChange={updateSetting}
        onZoteroLocalDataDirChange={setZoteroLocalDataDir}
        onMineruApiTokenChange={(value) => updateReaderSecret('mineruApiToken', value)}
        onTranslationApiKeyChange={(value) => updateReaderSecret('translationApiKey', value)}
        onSummaryApiKeyChange={(value) => updateReaderSecret('summaryApiKey', value)}
        onZoteroApiKeyChange={(value) => updateReaderSecret('zoteroApiKey', value)}
        onZoteroUserIdChange={(value) => updateReaderSecret('zoteroUserId', value)}
        onDetectLocalZotero={() => void handleDetectLocalZotero()}
        onSelectLocalZoteroDir={() => void handleSelectLocalZoteroDir()}
        onReloadLocalZotero={() => void handleReloadLocalZotero()}
        onSelectMineruCacheDir={() => void handleSelectMineruCacheDir()}
        onSelectRemotePdfDownloadDir={() => void handleSelectRemotePdfDownloadDir()}
        onTestLlmConnection={handleTestLlmConnection}
        onQaModelPresetAdd={addQaModelPreset}
        onQaModelPresetRemove={removeQaModelPreset}
        onQaModelPresetChange={updateQaModelPreset}
        onTranslate={activeReaderBridge?.onTranslate}
        onClearTranslations={activeReaderBridge?.onClearTranslations}
        onBatchMineruParse={() => void handleBatchMineruParse()}
        onBatchGenerateSummaries={() => void handleBatchGenerateSummaries()}
        onToggleBatchMineruPause={handleToggleBatchMineruPause}
        onCancelBatchMineru={handleCancelBatchMineru}
        onToggleBatchSummaryPause={handleToggleBatchSummaryPause}
        onCancelBatchSummary={handleCancelBatchSummary}
        batchMineruRunning={batchMineruRunning}
        batchSummaryRunning={batchSummaryRunning}
        batchMineruPaused={batchMineruPaused}
        batchSummaryPaused={batchSummaryPaused}
        batchMineruProgress={batchMineruProgress}
        batchSummaryProgress={batchSummaryProgress}
      />
      </div>
    </AppLocaleProvider>
  );
}

export default Reader;




