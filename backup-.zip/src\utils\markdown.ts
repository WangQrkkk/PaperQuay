const MATH_FENCE_START_PATTERN = /^```(?:latex|tex|math|katex)\s*$/i;
const CODE_FENCE_PATTERN = /^```/;
const PROTECTED_MATH_PATTERN =
  /(\$\$[^$]+\$\$|\$[^$\n]+\$|\\\([^)]*\\\)|\\\[[^\]]*\\\])/g;
const INLINE_FORMULA_START_PATTERN =
  /[A-Za-z0-9\\\u0370-\u03FF\u1F00-\u1FFF]/;
const INLINE_FORMULA_CHAR_PATTERN =
  /[A-Za-z0-9\\\u0370-\u03FF\u1F00-\u1FFF{}()[\]^_=+\-*/<>|~,:.;&\u00B7\u00D7\u00F7 ]/;
const INLINE_MATH_COMMAND_PATTERN =
  /\\(?:in|notin|subset|supset|forall|exists|times|cdot|sum|min|max|leq|geq|neq|approx|tag|cup|cap|to|rightarrow|leftarrow)\b/;
const SYMBOLIC_VARIABLE_PATTERN =
  /(?:[A-Za-z\u0370-\u03FF\u1F00-\u1FFF](?:\s*[_^]\s*(?:\{[^{}]+\}|[A-Za-z0-9\u0370-\u03FF\u1F00-\u1FFF]))?)/;
const VARIABLE_RELATION_PATTERN = new RegExp(
  `(?:^|[\\s,(])${SYMBOLIC_VARIABLE_PATTERN.source}` +
    `(?:\\s*,\\s*${SYMBOLIC_VARIABLE_PATTERN.source})*` +
    `\\s*(?:=|<|>|${INLINE_MATH_COMMAND_PATTERN.source})`,
);

function stripTrailingLatexLabel(value: string) {
  return value.replace(/\s+latex\s*$/i, '').trim();
}

function looksLikeStandaloneFormulaLine(value: string) {
  const trimmed = stripTrailingLatexLabel(value.trim());

  if (!trimmed) {
    return false;
  }

  if (
    /^#{1,6}\s/.test(trimmed) ||
    /^[-*+]\s/.test(trimmed) ||
    /^\d+\.\s/.test(trimmed) ||
    /^>/.test(trimmed) ||
    trimmed.includes('|') ||
    /^<[^>]+>/.test(trimmed)
  ) {
    return false;
  }

  if (
    (trimmed.startsWith('$$') && trimmed.endsWith('$$')) ||
    (trimmed.startsWith('$') && trimmed.endsWith('$')) ||
    (trimmed.startsWith('\\[') && trimmed.endsWith('\\]')) ||
    (trimmed.startsWith('\\(') && trimmed.endsWith('\\)'))
  ) {
    return false;
  }

  if (/[\u4e00-\u9fff]/.test(trimmed)) {
    return false;
  }

  // 排除 LaTeX 命令后再统计普通英文单词，避免把 `\boldsymbol`、`\quad`
  // 这类命令误判成自然语言，从而错过对整行公式的自动包裹。
  const plainWordMatches =
    trimmed
      .replace(/\\[A-Za-z]+/g, ' ')
      .match(
        /\b(?!latex\b)(?!tag\b)(?!min\b)(?!max\b)(?!sum\b)(?!forall\b)(?!exists\b)(?!argmin\b)(?!argmax\b)[A-Za-z]{3,}\b/g,
      ) ?? [];

  if (plainWordMatches.length >= 3) {
    return false;
  }

  const hasLatexCommand = /\\[A-Za-z]+/.test(trimmed);
  const hasMathStructure =
    /[_^=]/.test(trimmed) ||
    /\\(?:tag|frac|sum|min|max|forall|exists|boldsymbol|mathrm|left|right|cdot|times|cup|cap|in)\b/.test(
      trimmed,
    );
  const mathSymbolCount = (trimmed.match(/[\\_^=+\-*/()[\]{}<>|~]/g) ?? []).length;
  const symbolDensity = mathSymbolCount / Math.max(trimmed.length, 1);

  return hasLatexCommand && hasMathStructure && symbolDensity >= 0.08;
}

export function normalizeLatexExpression(value: string) {
  return stripTrailingLatexLabel(value)
    .replace(/\r\n?/g, '\n')
    .replace(/\\([A-Za-z]+)\s+\{/g, '\\$1{')
    .replace(/([_^])\s+\{/g, '$1{')
    .replace(/\s+([,.;:])/g, '$1')
    .replace(/\{\s+/g, '{')
    .replace(/\s+\}/g, '}')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

function isInlineFormulaBoundary(value: string | undefined) {
  return (
    value == null ||
    value === '' ||
    /[\s\u4e00-\u9fff`"'.,;:!?()[\]{}<>]/.test(value)
  );
}

function canStartInlineFormulaCandidate(value: string, index: number) {
  const tail = value.slice(index);

  if (tail.startsWith('\\')) {
    return true;
  }

  if (/^[\u0370-\u03FF\u1F00-\u1FFF]/.test(tail)) {
    return true;
  }

  if (!/^[A-Za-z0-9]/.test(tail)) {
    return false;
  }

  return /[_^]/.test(tail) || /[=<>]/.test(tail) || INLINE_MATH_COMMAND_PATTERN.test(tail);
}

function looksLikeInlineFormulaSegment(value: string) {
  const trimmed = stripTrailingLatexLabel(value.trim());

  if (!trimmed || trimmed.length < 2) {
    return false;
  }

  if (/[\u4e00-\u9fff]/.test(trimmed) || /^https?:\/\//i.test(trimmed)) {
    return false;
  }

  if (/[?&][A-Za-z0-9_]+=/.test(trimmed)) {
    return false;
  }

  if (
    (trimmed.startsWith('$$') && trimmed.endsWith('$$')) ||
    (trimmed.startsWith('$') && trimmed.endsWith('$')) ||
    (trimmed.startsWith('\\[') && trimmed.endsWith('\\]')) ||
    (trimmed.startsWith('\\(') && trimmed.endsWith('\\)'))
  ) {
    return false;
  }

  const hasLatexCommand = /\\[A-Za-z]+/.test(trimmed);
  const hasSubOrSup =
    /(?:^|[A-Za-z0-9)}\]])\s*[_^]\s*(?:\{[^{}]+\}|[A-Za-z0-9\\])/.test(trimmed);
  const hasMathOperator =
    /[=<>]/.test(trimmed) || INLINE_MATH_COMMAND_PATTERN.test(trimmed);
  const hasMathSpacing = /~/.test(trimmed);
  const hasSymbolicVariable = new RegExp(
    `(?:^|[\\s,(])${SYMBOLIC_VARIABLE_PATTERN.source}(?:[\\s,),]|$)`,
  ).test(trimmed);
  const hasVariableRelation = VARIABLE_RELATION_PATTERN.test(trimmed);

  return (
    hasLatexCommand ||
    hasSubOrSup ||
    hasVariableRelation ||
    ((hasMathOperator || hasMathSpacing) && hasSymbolicVariable)
  );
}

function wrapInlineLatexSegments(line: string) {
  if (!line.trim() || !/[\\_^=<>~]/.test(line)) {
    return line;
  }

  const protectedSegments: string[] = [];
  const protectedLine = line.replace(PROTECTED_MATH_PATTERN, (segment) => {
    const token = `\uE000${protectedSegments.length}\uE001`;
    protectedSegments.push(segment);
    return token;
  });

  let output = '';
  let index = 0;

  while (index < protectedLine.length) {
    const currentChar = protectedLine[index];

    if (
      !INLINE_FORMULA_START_PATTERN.test(currentChar) ||
      !canStartInlineFormulaCandidate(protectedLine, index)
    ) {
      output += currentChar;
      index += 1;
      continue;
    }

    let end = index;

    while (end < protectedLine.length && INLINE_FORMULA_CHAR_PATTERN.test(protectedLine[end])) {
      if (end > index && /^\s+[A-Za-z]{2,}\b/.test(protectedLine.slice(end))) {
        break;
      }

      end += 1;
    }

    const candidate = protectedLine.slice(index, end);

    if (
      candidate &&
      looksLikeInlineFormulaSegment(candidate) &&
      isInlineFormulaBoundary(protectedLine[index - 1]) &&
      isInlineFormulaBoundary(protectedLine[end])
    ) {
      const leadingWhitespace = candidate.match(/^\s*/)?.[0] ?? '';
      const trailingWhitespace = candidate.match(/\s*$/)?.[0] ?? '';
      const normalized = normalizeLatexExpression(candidate.trim());

      output += `${leadingWhitespace}$${normalized}$${trailingWhitespace}`;
      index = end;
      continue;
    }

    output += currentChar;
    index += 1;
  }

  return output.replace(
    /\uE000(\d+)\uE001/g,
    (_, rawIndex) => protectedSegments[Number(rawIndex)] ?? '',
  );
}

export function normalizeMarkdownMath(markdown: string) {
  if (!markdown.trim()) {
    return markdown;
  }

  const lines = markdown.replace(/\r\n?/g, '\n').split('\n');
  const output: string[] = [];
  let mathFenceBuffer: string[] | null = null;
  let insideOtherFence = false;

  const flushMathFence = () => {
    if (!mathFenceBuffer) {
      return;
    }

    const expression = normalizeLatexExpression(mathFenceBuffer.join('\n'));

    if (expression) {
      output.push('$$');
      output.push(expression);
      output.push('$$');
    }

    mathFenceBuffer = null;
  };

  for (const line of lines) {
    const trimmed = line.trim();

    if (mathFenceBuffer) {
      if (CODE_FENCE_PATTERN.test(trimmed)) {
        flushMathFence();
      } else {
        mathFenceBuffer.push(line);
      }

      continue;
    }

    if (insideOtherFence) {
      output.push(line);

      if (CODE_FENCE_PATTERN.test(trimmed)) {
        insideOtherFence = false;
      }

      continue;
    }

    if (MATH_FENCE_START_PATTERN.test(trimmed)) {
      mathFenceBuffer = [];
      continue;
    }

    if (CODE_FENCE_PATTERN.test(trimmed)) {
      insideOtherFence = true;
      output.push(line);
      continue;
    }

    if (looksLikeStandaloneFormulaLine(trimmed)) {
      output.push('$$');
      output.push(normalizeLatexExpression(trimmed));
      output.push('$$');
      continue;
    }

    output.push(wrapInlineLatexSegments(line));
  }

  flushMathFence();

  return output.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}
