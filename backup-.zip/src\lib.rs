mod commands;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
  tauri::Builder::default()
    .invoke_handler(tauri::generate_handler![
      commands::file::get_app_default_paths,
      commands::file::select_pdf_file,
      commands::file::select_json_file,
      commands::file::select_attachment_files,
      commands::file::capture_system_screenshot,
      commands::file::select_directory,
      commands::file::list_directory_files,
      commands::file::select_save_pdf_path,
      commands::file::read_text_file,
      commands::file::read_binary_file_base64,
      commands::file::write_text_file,
      commands::file::write_binary_file_base64,
      commands::file::download_remote_file_to_path,
      commands::mineru::run_mineru_cloud_parse,
      commands::mineru::run_mineru_placeholder,
      commands::llm::test_openai_compatible_chat,
      commands::translation::translate_blocks_openai_compatible,
      commands::summary::summarize_document_openai_compatible,
      commands::qa::ask_document_openai_compatible,
      commands::zotero::zotero_lookup_key,
      commands::zotero::zotero_list_library_items,
      commands::zotero::zotero_download_attachment_pdf,
      commands::zotero::zotero_detect_local_data_dir,
      commands::zotero::zotero_select_local_data_dir,
      commands::zotero::zotero_list_local_collections,
      commands::zotero::zotero_list_local_library_items,
      commands::zotero::zotero_list_local_collection_items,
      commands::zotero::zotero_list_related_notes
    ])
    .run(tauri::generate_context!())
    .expect("failed to run the PaperQuay application");
}
