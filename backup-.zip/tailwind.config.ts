import type { Config } from 'tailwindcss';

export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        chrome: {
          900: '#06111f',
          800: '#0f172a',
          700: '#1d2b3f',
        },
      },
      boxShadow: {
        panel: '0 20px 50px rgba(2, 6, 23, 0.28)',
      },
    },
  },
  plugins: [],
} satisfies Config;
