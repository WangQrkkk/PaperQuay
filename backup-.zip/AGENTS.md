你是一个资深桌面应用工程师兼前端架构师，请为我生成一个“轻量级论文阅读器”桌面应用项目。这个项目不是浏览器优先，而是**桌面应用优先**，宿主框架固定为 **Tauri v2**，前端固定为 **Vite + React + TypeScript**閵?

璇蜂綘涓ユ牸鎸夌収鈥滄闈㈠簲鐢ㄤ紭鍏堚€濈殑鎬濊矾璁捐锛屼笉瑕佹妸瀹冨綋鎴愪竴涓櫘閫?Web 妞ょ敻娼伴崥搴ｇ敾閸愬秹銆庨幍瀣悑鐎?Tauri閵?
我要的是一个真正的桌面端论文阅读器，主要运行环境是??

* macOS
* Windows
* Linux

前端技术栈固定为：

* Tauri v2
* Vite
* React
* TypeScript
* TailwindCSS
* react-pdf（基??pdf.js??
* react-markdown
* remark-gfm
* remark-math
* rehype-katex

后端/宿主能力层：

* Rust??Tauri commands??
* Tauri 插件按需使用
* ????????????????? Tauri ????????????

项目目标??
构建一个桌面端论文阅读器，核心能力??**PDF ??????** ??**MinerU 解析结构块视??* ??*?????????**??

---

## 涓€銆侀」鐩畾浣嶏紙蹇呴』涓ユ牸閬靛畧锛?

???????????????????????????

?????????????????

1. Tauri v2 ??????????????
2. 前端 UI 使用 React + Vite + TypeScript
3. 文件打开流程优先使用桌面应用能力??

   * 文件选择??
   * 本地路径
   * 本地缓存
4. ??????????????????????????input file ??????????
5. 项目结构要体现：

   * 前端 UI 鐏?
   * Tauri/Rust 鐎瑰じ瀵岄懗钘夊鐏?
   * MinerU 数据转换??
   * PDF 几何联动??

---

## 二、核心需??

我要实现一个左右分栏的桌面论文阅读器：

?????

* PDF 视图
* 使用 react-pdf 渲染
* 支持多页
* 每一页有 bbox 热区 overlay
* 鼠标移动到块上时高亮
* 点击块时激活并联动右侧

?????

* MinerU ??????/ ???????????
* ????????????????????????????
* 每个块有 data-block-id
* 点击块时左侧 PDF 跳到对应页并高亮对应 bbox

联动主逻辑必须是：

* blockId
* pageIndex
* bbox

不要把文本模糊匹配作为主方案??

---

## 三、MinerU 数据前提（必须理解）

MinerU ????????? markdown，而是按页分组的二维数组，例如??

```json id="9cuh4j"
[
  [
    {
      "type": "paragraph",
      "content": {
        "paragraph_content": [
          {
            "type": "text",
            "content": "There are also other civilian applications..."
          }
        ]
      },
      "bbox": [78, 102, 485, 259]
    }
  ]
]
```

请正确理解：

* 最外层数组：页数组
* 每一页：block 数组
* ??? block??

  * type
  * content
  * bbox
* bbox = [x1, y1, x2, y2]
* bbox 琛ㄧず璇ュ潡鍦ㄥ綋鍓?PDF 椤甸潰鍧愭爣绯讳腑鐨勭煩褰㈠尯鍩?

因此，PDF 閼辨柨濮╄箛鍛淬€忓铏圭彌閸︺劏绻栨稉顏勫殤娴ｆ洘鏆熼幑顔荤娑撳鈧?

---

## 四、联动原则（最重要??

### 1. 左侧 PDF -> 右侧

????????????????????????

?????????????

* ??????????????????bbox???? PDF ???????????????????? overlay
* ????????????blockId
* 鼠标 hover 到哪个热区，就高亮哪个块
* 点击哪个热区，就直接得到 blockId
* 鍙充晶婊氬姩鍒板搴?data-block-id 的块，并短暂高亮

### 2. 右侧 -> 左侧

* 鐐瑰嚮鍙充晶浠绘剰鍧?
* 直接拿该 block 的：

  * pageIndex
  * bbox
  * blockId
* 左侧 PDF 滚动到对应页
* ?????bbox ????????????

### 3. 文本匹配只能作为极端兜底

当前版本的主逻辑必须是几何块联动，不是字符串搜索??

---

## 浜斻€侀」鐩粨鏋勮姹?

请输出一个清晰的 Tauri v2 项目目录，至少包括：

```text id="6vd0kx"
paper-reader/
├─ src/
閳? ├─ app/
閳? 閳? ├─ App.tsx
閳? 閳? └─ index.css
閳? ├─ components/
閳? ├─ features/
閳? 閳? ├─ reader/
閳? 閳? 閳? └─ Reader.tsx
閳? 閳? ├─ pdf/
閳? 閳? 閳? └─ PdfViewer.tsx
閳? 閳? └─ blocks/
閳? 閳?    └─ BlockViewer.tsx
閳? ├─ services/
閳? 閳? ├─ mineru.ts
閳? 閳? └─ desktop.ts
閳? ├─ types/
閳? 閳? └─ reader.ts
閳? ├─ utils/
閳? 閳? ├─ bbox.ts
閳? 閳? └─ text.ts
閳? ├─ main.tsx
閳? └─ vite-env.d.ts
├─ src-tauri/
閳? ├─ src/
閳? 閳? ├─ main.rs
閳? 閳? ├─ lib.rs
閳? 閳? └─ commands/
閳? 閳?    ├─ mod.rs
閳? 閳?    ├─ file.rs
閳? 閳?    └─ mineru.rs
閳? ├─ tauri.conf.json
閳? └─ Cargo.toml
├─ package.json
├─ tsconfig.json
├─ vite.config.ts
└─ README.md
```

?????

* 鍓嶇鍜?Rust 宿主边界清晰
* 桌面能力通过 Tauri command 暴露
* ?????????????????????

---

## ??????????????

请定义完??TypeScript ??????????????

```ts id="xz5ael"
export type BBox = [number, number, number, number];

export type PdfSource =
  | { kind: 'local-path'; path: string }
  | { kind: 'remote-url'; url: string }
  | null;

export interface MineruBlockBase {
  type: string;
  content: unknown;
  bbox?: BBox;
}

export type MineruPage = MineruBlockBase[];

export interface PositionedMineruBlock extends MineruBlockBase {
  blockId: string;
  pageIndex: number;
  blockIndex: number;
}

export interface PdfHighlightTarget {
  blockId: string;
  pageIndex: number;
  bbox: BBox;
}
```

???????????????block.type 可能包括??

* paragraph
* title
* list
* image
* table
* caption
* equation
* page_header
* page_footer
* page_number
* page_footnote

---

## ??????????????Tauri / Rust??

请不要把文件打开只写成普??`<input type="file">`??

閹存垼顩﹀宀勬桨鎼存梻鏁ゆ担鎾荤崣閿涘苯娲滃銈堫嚞閸?Rust/Tauri 灞傛彁渚涙闈㈣兘鍔涖€?

### 1. 打开本地 PDF

鐠囩柉顔曠拋鈥茬娑?Tauri command 閹存牕鐔€娴?Tauri 鎻掍欢鑳藉姏鐨勬帴鍙ｏ紝鐢ㄤ簬锛?

* 选择本地 PDF
* 返回本地路径
* 前端保存??PdfSource = { kind: 'local-path', path }

### 2. 读取 MinerU JSON

???????????`content_list_v2.json`

* Rust 读取 JSON 文件内容
* 返回给前端解??
* 或前端通过 path 请求 Rust 读取

### 3. 后续可扩??

请在结构上预留：

* 调用本地 Python / 本地后端 / 远程 MinerU API
* 閹?PDF 发给 MinerU，返回块结构 JSON

?????
现在可以??mock ?????????? JSON，但架构上必须像真实桌面应用??

---

## 八、服务层要求

请实现以下前端服务模块：

### services/desktop.ts

璐熻矗涓?Tauri 通信，例如：

* 打开本地 PDF
* 读取本地 JSON
* 调用 Rust command

### services/mineru.ts

??????

1. flattenMineruPages(pages: MineruPage[]): PositionedMineruBlock[]
2. extractTextFromMineruBlock(block: PositionedMineruBlock): string
3. buildRenderableBlocks(blocks: PositionedMineruBlock[])
4. 閸欘垶鈧?convert block -> markdown fragment

请注意：
???????????????? markdown，一定要保留块级信息??

---

## ???????PDF ??????PdfViewer.tsx??

??????? react-pdf??????????

1. 开??TextLayer
2. 关闭 AnnotationLayer
3. 必须引入 TextLayer.css
4. 必须正确初始??pdfjs worker
5. 支持多页渲染
6. 濮ｅ繋绔存い鐢稿厴韫囧懘銆忛弰顖椻偓婊呮祲鐎电懓鐣炬担宥咁啇閸ｃ劉鈧?

### 核心要求：PDF 热区 overlay

濮ｅ繋绔存い鍏哥瑐韫囧懘銆忛崣鐘插娑撯偓娑?overlay 层，overlay 涓牴鎹綋鍓嶉〉鐨?blocks 閻㈢喐鍨氭径姘嚋缂佹繂顕€规矮缍呴悜顓炲隘閵?

#### 热区生成规则

* ?????????????PositionedMineruBlock
* 热区坐标来自 bbox
* 鐑尯鍙负姝ｆ枃鐩稿叧鍧楀缓绔?
* 默认排除??

  * page_header
  * page_footer
  * page_number
  * page_footnote

#### 交互

* hover??

  * 更新 hoveredBlockId
  * 当前热区浅黄色半透明高亮
* click??

  * 更新 activeBlockId
  * 调用 onBlockSelect(block)

### active 楂樹寒妗?

PdfViewer 还要支持??

* activeHighlight: PdfHighlightTarget | null
  当右侧点击块时，如果当前页是 activeHighlight.pageIndex閿涘苯鍨崷銊ヮ嚠鎼?bbox 鍖哄煙缁樺埗鏇存槑鏄剧殑楂樹寒妗嗐€?

### bbox 坐标换算

?????????

* ?? PDF 页尺??
* 当前渲染页尺??
* scaleX / scaleY
* bbox -> CSS absolute style

需要明确写出公式：

```ts id="2v9v2h"
left = x1 * scaleX
top = y1 * scaleY
width = (x2 - x1) * scaleX
height = (y2 - y1) * scaleY
```

---

## ?????????????BlockViewer.tsx??

娑撳秷顩﹂幎濠傚礁娓氀呯暆閸楁洖浠涢幋鎰ㄢ偓婊勬殻缁?markdown 娑撯偓濞嗏剝鈧勮閺屾挴鈧縿鈧?

请采用“块级渲染”方式：

* 每个 PositionedMineruBlock 单独渲染
* 每个块最外层都有??

  * data-block-id={block.blockId}

??????????????????

* title
* paragraph
* list
* image（先渲染 caption 或占位）
* table??????? caption ??html ռλ??

鍐呴儴鍙互灞€閮ㄤ娇鐢?react-markdown 濞撳弶鐓嬮崸妤佹瀮閺堫剨绱濊箛鍛淬€忛弨顖涘瘮閿?

* remark-gfm
* remark-math
* rehype-katex
* katex.min.css

### 右侧交互

* 点击块时??

  * onBlockClick(block)
* 瑜?activeBlockId 变化时：

  * 自动 scrollIntoView({ behavior: 'smooth', block: 'center' })
  * ???? 1.5 ??
* 瑜?hoveredBlockId 变化时：

  * 可选显示较??hover ???

---

## ????????????Reader.tsx??

Reader.tsx 统一管理??

* pdfSource: PdfSource
* mineruPages: MineruPage[]
* flatBlocks: PositionedMineruBlock[]
* activeBlockId: string | null
* hoveredBlockId: string | null
* activePdfHighlight: PdfHighlightTarget | null
* loading: boolean
* error: string

并负责以下交互：

### A. ????? PDF ??

* 接收 onBlockSelect(block)
* 设置 activeBlockId = block.blockId
* 鍙充晶婊氬姩瀹氫綅鍒?block.blockId

### B. ??? hover PDF ??

* 更新 hoveredBlockId

### C. 右侧点击??

* 设置 activeBlockId = block.blockId
* 设置 activePdfHighlight = {
  blockId,
  pageIndex,
  bbox
  }

### D. 打开本地文件

* 调用 Tauri 桌面能力打开 PDF
* 读取对应 MinerU JSON
* 鍒濆鍖?blocks

---

## ????????????UI ???

杩欐槸妗岄潰搴旂敤锛屼笉鏄綉椤?demo锛岃淇濇寔妗岄潰搴旂敤椋庢牸锛?

* 窗口 100vh / 100vw
* 左右等宽双栏
* 顶部工具??
* 左侧 PDF 独立滚动
* 右侧块视图独立滚??
* 风格简洁、专业、偏学术工具
* TailwindCSS 实现
* ???????/ ??????/ ???????

建议工具栏包含：

* 打开本地 PDF
* 打开 MinerU JSON
* 当前文件??
* 当前激活块信息
* ??????

---

## 十三、Rust 代码要求

请生成最小可用的 Tauri Rust 代码，包括：

* main.rs / lib.rs
* command 注册
* 一个读取本地文件文本的 command
* 涓€涓€夋嫨鏂囦欢璺緞鐨?command 或可替代实现
* 错误处理
* 鍓嶅悗绔皟鐢ㄧず渚?

?????

* Rust 代码尽量简??
* 只做桌面能力桥接
* 业务核心仍放前端
* 代码能作??Tauri v2 ??????

---

## 十四、不要这样实??

请不要把项目设计成：

1. 一个普通浏览器页面后面再“顺便加 Tauri閳?
2. 左侧只监??TextLayer ???????
3. 主联动靠 normalizeText / includes / 全文搜索
4. 鍙充晶鍙覆鏌撴暣绡?markdown閿涘矁鈧本鐥呴張澶婃健缁?DOM 锚点
5. ????????????????????File API

---

## 鍗佷簲銆佽緭鍑洪『搴?

请按以下顺序输出完整代码和说明：

1. 完整目录结构
2. package.json 依赖建议
3. src-tauri/Cargo.toml 依赖建议
4. TypeScript 类型定义
5. src/services/desktop.ts
6. src/services/mineru.ts
7. src/features/reader/Reader.tsx
8. src/features/pdf/PdfViewer.tsx
9. src/features/blocks/BlockViewer.tsx
10. src-tauri/src/main.rs
11. src-tauri/src/lib.rs
12. src-tauri/src/commands/file.rs
13. src-tauri/src/commands/mod.rs
14. bbox 坐标换算逻辑说明
15. PDF 热区 overlay 设计说明
16. hover / active / click 双向联动说明
17. 当前 MVP 鐨勯檺鍒朵笌鍚庣画鍙墿灞曟柟鍚?

?????

* 代码必须可运??
* 所有代码使??TypeScript ??Rust
* 注释全部使用中文
* 桌面应用优先
* 鑱斿姩蹇呴』浠ュ嚑浣曞潡涓轰富锛屼笉鏄枃鏈尮閰?
* 左侧 PDF 必须通过 bbox 建立热区 overlay
* 鼠标滑动到哪个块就高亮哪个块
* 鐐瑰嚮鍝釜鍧楀氨鐩存帴瀹氫綅鍙充晶瀵瑰簲鍧?
